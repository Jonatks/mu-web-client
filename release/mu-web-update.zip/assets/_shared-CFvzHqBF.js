import{af as $n,fC as ss,P as Ze,ag as rs,a as At,o as _t,fK as In,ec as is,bs as ls,fL as so,fM as Dn,fN as cs,fO as hs,fP as us,g as fs,fQ as ds,fR as ps,fS as ms,C as gs,fT as vs,l as Nn,fU as ws,fV as Ss,i as ys,h as bs,fW as Es,fX as Ls,fY as xs,cs as Tt,cH as Pn,fZ as As,cR as zn,bh as Hn,aj as S,f_ as _s,f$ as Ts,g0 as Ms,b3 as b,b9 as z,b6 as A,bd as N,b7 as ge,g1 as Rs,bq as Os,bg as Gn,b4 as Fn,an as w,ak as C,be as Un,bu as Cs,b5 as K,x as Wn,ao as ks,aB as $s,bD as Bn,bB as $o,ba as xe,am as Is,al as Ds,b8 as Io,bm as Ns,aE as Ps}from"./index-CAiyeLaW.js";import{av as zs,bW as Hs,cB as Gs,cC as Fs,cD as Us,cE as Ws,cF as Bs,cG as Kn,cH as Ks,cI as Vs,cJ as Ys,cK as qs,cL as js,cM as Xs,cN as Zs,cO as Js,cP as Qs,cQ as er,cR as tr,cS as or,cT as nr,cU as ar,b9 as sr,cw as rr,ba as ir,b8 as lr,cV as cr,cW as hr,cr as ur,cd as fr,cX as dr,cY as pr,p as Vn,cy as mr,cZ as gr,bh as vr,bi as wr,be as Do,aB as Yn,S as Sr,c_ as No,bU as Po,bI as yr,a5 as qn,c$ as br,O as q,K as ue,L as jn}from"./playerNpcTables-DTbyKYhR.js";import{fg as Er}from"./packets-6gq2tbY3.js";import{j as Je,B as le,E as W,G as J,h as Lr,a as ve,M as xr,P as zo}from"./playerActionMapper-DJZJq3fp.js";import{m as Ar,o as _r}from"./index-BqRme67w.js";import{S as Tr,l as Xn,T as Ae,d as m,J as Ho,a1 as Mr,b as Zn,L as Rr,h as Or,I as Go,f as he}from"./bjs-Bo1IUMoc.js";const Cr=6,Qe=Cr/$n;let Te=Qe;function kr(){return Te>=Qe}function $r(){return Math.max(0,Qe-Te)}function Ir(){Te=0}function Dr(e,t){Te<Qe&&(Te+=t)}function Nr(){Te=Qe}const Pr={name:"inputGate",update:Dr,reset:Nr},zr=1.8,Hr=2.2,Gr=6,Fo=3,ro=4,io=7,lo=15,Fr=new Set([8,9,10,11,12,13,14,16,18,19]);function mt(e){return!!e&&e.group===ro&&(e.num===io||e.num===lo)}function Uo(e){return!!e&&e.group===ro&&!mt(e)}function Jn(e){return Fr.has(e.num)}function et(e){return e?Uo(e.leftHand)?e.leftHand:Uo(e.rightHand)?e.rightHand:null:null}function Hu(e){const t=et(e);return!t||!e?null:t===e.leftHand?e.rightHand:e.leftHand}function Ur(e){return et(e)?Gr:e?.leftHand?.group===Fo&&!mt(e.leftHand)||e?.rightHand?.group===Fo&&!mt(e.rightHand)?Hr:zr}function Wr(e){const t=et(e);if(!t||!e)return!0;const o=t===e.leftHand?e.rightHand:e.leftHand;if(!mt(o))return!1;const n=Jn(t)?io:lo;return o.num!==n?!1:o.durability===void 0||o.durability>0}const Qn=new Set;function Gu(e,t,o,n,a){const l=et(e);if(!l||!e)return null;const r=l===e.leftHand;if((r?e.rightHand:e.leftHand)!==null)return null;const i=Jn(l)?io:lo,s=r?a:n;for(let c=t.length-1;c>=o;c--){const h=t[c];if(h&&h.group===ro&&h.num===i)return{from:c,to:s}}return{from:-1,to:s}}const Br={name:"weaponRange"},ea={},Fu=3,ta=new Set;function Kr(e){return ea[e]??null}function Vr(e,t){const o=t.x-e.x,n=t.y-e.y,a=Math.hypot(o,n);return a<.001?null:{x:t.x-o/a,y:t.y-n/a}}function Yr(e){return ta.has(e)}const qr={name:"skillMovement"};function Uu(e,t){return t.duelEnemyId!==null?e.netId===t.duelEnemyId:(e.heroState??zs)>=Hs?!0:t.ctrl}const jr={name:"playerTarget"},Xr="AreaSkillExplicitHits",oa=new Set,Zr=1.5,Jr=20,Wo=9,Bo=3;let ut=0,ft=0;function Qr(e){return e.type===Xr||oa.has(e.num)}function ei(e){return e.range>0?e.range+.5:Zr}function ti(e,t,o,n){if(n.length===0)return null;const a=n.slice(0,Jr);ut=ut+1&255,ft=ft+1&255;const l=Wo+a.length*Bo,r=Er.createPacket(l);r.SkillId=e,r.TargetX=t,r.TargetY=o,r.HitCounter=ut,r.TargetCount=a.length;const i=r.buffer;for(let s=0;s<a.length;s++){const c=Wo+s*Bo;i.setUint16(c,a[s],!1),i.setUint8(c+2,ft)}return r.writeLength(l),r}function oi(e,t){}function ni(){ut=0,ft=0}const ai={name:"areaHit",update:oi,reset:ni},si=[Pr,Gs,Br,Fs,qr,Us,jr,ai],O={},na={};function ri(e){return na[e]}function ii(e,t,o){t.clip&&(Ks[e]=t.clip),t.poseClip&&(Vs[e]=t.poseClip),t.swing&&(Ys[e]=t.swing),t.swordCount!==void 0&&(qs[e]=t.swordCount),t.castsAsSpell&&Ws.add(e),t.checksArrows&&Qn.add(e),t.othersSee&&(js[e]=t.othersSee),t.quietOn&&(Xs[e]=t.quietOn),t.magicIsHit&&Bs.add(e);for(const n of t.noFlinch??[])Kn.add(n);for(const n of t.holdsFacing??[])ta.add(n);t.target&&(Zs[e]=t.target),t.stepIn&&(ea[e]=t.stepIn),t.explicitHits&&oa.add(e),t.kill&&(na[e]=t.kill),t.combat?.layer&&o(t.combat.layer),Object.assign(O,t.combat?.hooks)}class li{id="combat";layers=[...si];register(t){return this.layers.push(t),()=>{const o=this.layers.indexOf(t);o>=0&&this.layers.splice(o,1)}}registerSkill(t,o){ii(t,o,n=>this.register(n))}layersFor(t){return this.layers.filter(o=>!o.maps||o.maps.has(t))}update(t,o){for(const n of this.layers)n.update?.(t,o)}reset(){for(const t of this.layers)t.reset?.()}get inputGateOpen(){return kr()}get inputGateRemaining(){return $r()}consumeInputGate(){Ir()}get attackTime(){return Js()}get attackInFlight(){return Qs()}checkAttackTime(t){return er(t)}setLastAttackEffectTime(){dr()}startAttack(t,o,n,a){return tr(t,o,n,a)}hitDelaySeconds(t,o){return or(t,o)}releasesOnKey(t,o){return nr(t,o)}get blowHeldTicks(){return ar()}cancelAttack(){pr()}attackRange(t){return Ur(t)}hasAmmo(t){return Wr(t)}equippedLauncher(t){return et(t)}checksArrows(t){return Qn.has(ss(t))}skillClip(t,o){return sr(t,o)}magicClip(t){return rr(t)}othersSeeClip(t,o){return ir(t,o)}castQuietOn(t,o){return lr(t,o)}magicIsHit(t){return cr(t)}clipIgnoresHit(t){return Kn.has(t)}skillKill(t){return ri(t)}skillStepIn(t){return Kr(t)}stepInSquare(t,o){return Vr(t,o)}clipHoldsFacing(t){return Yr(t)}castTarget(t){return hr(t)}castsOnSelf(t){return ur(t)}castsOnSelfOnly(t){return fr(t)}get novaSkill(){return O.nova?.skill??-1}get novaBeginSkill(){return O.nova?.beginSkill??-1}get novaCharging(){return O.nova?.charging()??!1}get novaCharge(){return O.nova?.charge()??0}get novaStage(){return O.nova?.stage()??0}beginNova(){return O.nova?.begin()??!1}releaseNova(){return O.nova?.release()??0}needsAreaHit(t){return Qr(t)}areaHitRadius(t){return ei(t)}buildAreaHit(t,o,n,a){return ti(t,o,n,a)}get comboFlash(){return O.combo?.flash()??0}get combosLanded(){return O.combo?.landed()??0}comboKnockUp(t){return O.combo?.knockUp(t)??!1}observeSkillAnimation(t,o){return O.combo?.observeSkillAnimation(t,o)??!1}isDarkSide(t){return O.darkSide?.isDarkSide(t)??!1}beginDarkSide(t,o){O.darkSide?.begin(t,o)}observeDarkSideTargets(t,o){O.darkSide?.observeTargets(t,o)}observeDarkSideEcho(t,o){return O.darkSide?.observeEcho(t,o)??!1}observeDarkSideMagic(t,o,n){return O.darkSide?.observeMagic(t,o,n)??!1}observeRageHit(t,o){O.darkSide?.observeRageHit(t,o)}get rageStreak(){return O.darkSide?.streak()??0}}const co=new li,ho="combat",ci=10,hi=0,ui=["Sound/eMeleeHit1","Sound/eMeleeHit2","Sound/eMeleeHit3","Sound/eMeleeHit4"],fi=["Sound/eMissileHit1","Sound/eMissileHit2","Sound/eMissileHit3","Sound/eMissileHit4"],di=["Sound/pMaleScream1","Sound/pMaleScream2","Sound/pMaleScream3"],Vt={},pi=new Set,aa={};function Wu(e,t){return aa[e]?.(t)??null}function Bu(e){return e in aa}const mi={};function Ku(e,t=!1){return pi.has(e)?null:ra(e)??(t?mi[e]??null:null)}const _e=e=>Math.floor(Math.random()*e);function Vu(e){const t=e?.rightHand??null,o=e?.leftHand??null,n=gr(e??void 0);return n==="bow"?"Sound/eBow":n==="crossbow"?"Sound/eCrossbow":o&&(o.group===vr&&o.num===ci||o.group===wr&&o.num===hi)?"Sound/eSwingLightSword":Do(t)||Do(o)?_e(2)?"Sound/eSwingWeapon2":"Sound/eSwingWeapon1":null}function Yu(e){const t=e?.rightHand??null,o=e?.leftHand??null;return No(t)||No(o)||Po(t)||Po(o)}function qu(e){return e?fi[_e(4)]:ui[_e(4)]}function ju(e){return Yn(e)?_e(2)?"Sound/pFemaleScream2":"Sound/pFemaleScream1":Je(e)===le.DarkLord&&_e(5)?"Sound/pDarkPain":di[_e(3)]}function Xu(e){return Yn(e)?"Sound/pFemaleScream2":Je(e)===le.DarkLord?"Sound/pDarkDeath":"Sound/pMaleDie"}const sa=new Set;function ra(e){return sa.has(e)?null:Vt[e]??Vt[mr(e)]??null}function gi(e,t){sa.has(e)&&Me(Vt[e]??null,t)}function Zu(e){if(e.group===12&&[15,30,31].includes(e.num))return"jewel";if(e.group===14){if([13,14,16,22,31].includes(e.num))return"jewel";if(e.num===41)return"gemstone"}return"getItem"}const vi={bus:ho},wi={bus:ho,channels:1};function Me(e,t){e&&Vn(e,t,e==="Sound/pHeartBeat"?wi:vi)}function Ju(e){Sr.stopAmbientLoop(e)}function Qu(e,t){Me(ra(e),t)}const ef={name:"combat"},Si=40,Ko=20,tf=$n;function gt(e){return e>=W.WD_18CHAOS_CASTLE&&e<=W.WD_18CHAOS_CASTLE_END||e===W.WD_53CAOSCASTLE_MASTER_LEVEL}function of(e){return e===W.WD_9DEVILSQUARE||e===W.WD_32DEVILSQUARE_5_7}function nf(e){return e>=W.WD_11BLOODCASTLE1&&e<=W.WD_11BLOODCASTLE_END||e===W.WD_52BLOODCASTLE_MASTER_LEVEL}function yi(e){return e>=W.WD_24HELLAS&&e<=W.WD_24HELLAS_END||e===W.WD_24HELLAS_7}function bi(e){return e===W.WD_7ATLANSE||yi(e)||e===W.WD_67DOPPLEGANGER3}function af(e,t,o,n,a=!1){if(a)return!0;const l=Je(e);if(l===le.Knight||l===le.DarkLord||l===le.RageFighter)return!0;const i=bi(n)?o:t;return!!i&&(i.lvl??0)>=5}const Ei=12,Vo=15,Li=15,xi=16,Ai=4;function sf(e){return e.fenrir&&!e.inSafeZone?gt(e.world):(e.wings||e.riding)&&!e.inSafeZone?!0:gt(e.world)}function rf(e){let t;return e.fenrir&&!e.inSafeZone?e.run<Ko/2?t=15:e.run<Ko?t=16:t=e.fenrirUpgraded?19:17:(e.wings||e.riding)&&!e.inSafeZone?t=yr(e.wings)?xi:Li:t=e.run>=Si?Vo:Ei,gt(e.world)&&(t=Vo),t/Ai}const Yo={group:0,num:16,lvl:0},_i={group:4,num:19,lvl:0},Ti={group:5,num:5,lvl:0};function ia(e,t){return gt(t)&&!e.skin&&e.npcType===void 0}function la(e){switch(e){case le.Elf:return{leftHand:_i,rightHand:null};case le.Wizard:case le.Summoner:return{leftHand:Ti,rightHand:null};default:return{leftHand:Yo,rightHand:Yo}}}function Mi(e,t){const o=e.charAppearance;return!o||!ia(e,t)?o:la(Je(o.charClass))}function lf(e,t){const o=e.charAppearance;return!o||!ia(e,t)?o:{...la(Je(o.charClass)),helm:null,armor:null,pants:null,gloves:null,boots:null}}const Ri=new class{weather={weather:0,variation:0};constructor(){Ar(this,{weather:_r})}},Oi=1,Ci=26,ki=45,$i=1/Ci,Ii=1/ki;let j=0,Yt=!1;function Di(e){return Ze.layerFor(e)?.weather?.alwaysRain===!0}function ca(e){if(Di(e))return 1;if(!Ze.canRain(e))return 0;const{weather:t,variation:o}=Ri.weather;return t!==Oi?0:Math.min(1,o*6/100)}function Ni(e,t){const o=ca(e);return Yt?(j<o?j=Math.min(o,j+$i*t):j>o&&(j=Math.max(o,j-Ii*t)),j):(Yt=!0,j=o,j)}function uo(){return j}function Pi(){j=0,Yt=!1}const zi={name:"rain",update:Ni,reset:Pi},ha=Ze.worldSet(e=>e.weather?.wetGround===!0),Hi=22,Gi=150,Fi=1.6,qo=.35,Ui=45,Wi=210;let F=0,X=0,dt=null;function Bi(e,t){if(!ha.has(e))return F=0,X=0,dt=e,0;if(e!==dt){dt=e;const l=ca(e);return F=l,X=l>qo?l*.5:0,F}const o=uo(),n=Math.min(1,o*Fi);return F<n?F=Math.min(n,F+o*t/Hi):F=Math.max(n,F-t/Gi),o>0&&F>=qo?X=Math.min(1,X+o*t/Ui):X=Math.max(0,X-t/Wi),X=Math.min(X,F),F}function ua(){return F}function fa(){return X}function Ki(){return X>.3}function Vi(){F=0,X=0,dt=null}const Yi={name:"wetness",maps:ha,update:Bi,reset:Vi},fo=["boot","paw","claw","hoof","chitin","pad"],jo={boot:{shape:"boot",scale:1,stride:.5,side:.14,feet:2,reach:0,press:1,spray:1},stomp:{shape:"pad",scale:1.9,stride:.95,side:.26,feet:2,reach:0,press:1,spray:1.6},barefoot:{shape:"paw",scale:1.35,stride:.62,side:.18,feet:2,reach:0,press:1,spray:1.1},paw:{shape:"paw",scale:.85,stride:.55,side:.16,feet:4,reach:.75,press:.75,spray:.7},claw:{shape:"claw",scale:1.1,stride:.6,side:.16,feet:2,reach:0,press:1,spray:.9},beast:{shape:"claw",scale:1.35,stride:.8,side:.22,feet:4,reach:1,press:1,spray:1.2},cloven:{shape:"hoof",scale:1,stride:.58,side:.15,feet:2,reach:0,press:1,spray:.9},hoof:{shape:"hoof",scale:.95,stride:.62,side:.17,feet:4,reach:.85,press:1,spray:.8},chitin:{shape:"chitin",scale:.7,stride:.34,side:.22,feet:4,reach:.45,press:.8,spray:.25},none:{shape:"none",scale:1,stride:1,side:0,feet:2,reach:0,press:0,spray:0}},qi={0:"cloven",1:"paw",2:"none",5:"stomp",6:"none",7:"none",8:"chitin",9:"chitin",10:"stomp",11:"beast",12:"barefoot",13:"barefoot",15:"stomp",17:"paw",20:"chitin",21:"chitin",23:"stomp",24:"paw",25:"stomp",26:"cloven",27:"stomp",30:"hoof",31:"none",33:"beast",34:"none",36:"claw",37:"none",39:"stomp",41:"stomp",43:"paw",50:"none",51:"none",54:"claw",55:"none",58:"beast",64:"stomp",69:"stomp",81:"claw",82:"stomp",83:"none",84:"stomp",95:"paw",101:"stomp",102:"hoof",104:"stomp",105:"beast"};function cf(e){return e===void 0?jo.boot:jo[qi[rs(e)]??"boot"]}const ji={hero:64,crowd:128},It=.012,k={length:.42,width:.32,depth:.34,wallEdge:.5,ao:.45,ambient:.7,rim:.8,sink:.6,tint:[.62,.66,.76]},M=96,vt=4,da=vt;function Re(e){return fo.indexOf(e)}function pa(){return[1/da,1/fo.length]}function Xi(e,t,o){const[n,a]=pa(),l=Math.max(0,Re(t));return[o*n,l*a]}const wt=.62,Zi={boot:1,paw:1.3,claw:1.45,hoof:.95,chitin:.6,pad:1.35,none:1};function ma(e="boot"){return k.width*Zi[e]/wt}function po(){return k.length/wt}const Xo=6,Ji=10;function hf(e){return e<=Xo?1:Math.max(0,1-(e-Xo)/Ji)}const Qi={wet:[.45,.48,.56],snow:[.85,.92,1]},el={wet:.85,snow:1},tl={wet:22,snow:55},Zo=.55,ol={x:0,y:1,z:0},Oe=new Map,nl=(e,t)=>`${e}|${t}`;function Le(e,t){const o=Math.sin(e*127.1+t*311.7)*43758.5453;return o-Math.floor(o)}function se(e,t){const o=Math.floor(e),n=Math.floor(t);let a=e-o,l=t-n;a=a*a*(3-2*a),l=l*l*(3-2*l);const r=Le(o,n),i=Le(o+1,n),s=Le(o,n+1),c=Le(o+1,n+1);return r+(i-r)*a+(s-r)*l+(r-i-s+c)*a*l}const fe=(e,t,o)=>{const n=Math.min(1,Math.max(0,(o-e)/(t-e)));return n*n*(3-2*n)},re={cu:.5,cv:.5,ru:wt/2,rv:wt/2,power:2.05,waist:.3,waistAt:-.1,ball:.1};function al(e){const t=o=>Le(e*7.3+o*3.1,e*2.9+o*5.7)-.5;return{power:re.power+t(0)*.35,waist:re.waist+t(1)*.14,ball:re.ball+t(2)*.08,waistAt:re.waistAt+t(3)*.1,nu:e*37.1,nv:e*53.7}}function te(e,t,o){return 1-Math.pow(Math.pow(Math.abs(e),o)+Math.pow(Math.abs(t),o),1/o)}function sl(e,t,o,n){switch(e){case"paw":{const a=.54+.22*fe(-1,.2,o);let l=te(t/a,(o+.38)/.55,2.5);for(let r=0;r<4;r++){const i=(r-1.5)/1.5,s=.62-Math.abs(i)*.13;l=Math.max(l,te((t-i*.72)/.19,(o-s)/.25,2.2))}return l}case"claw":{let a=te(t/.4,(o+.5)/.4,2.4);for(let l=0;l<3;l++){const r=(l-1)*.62,i=Math.sin(r),s=Math.cos(r),c=t-i*.68,h=o-(.04+s*.5),f=c*i+h*s,p=c*s-h*i,v=.25*(1-.55*fe(-.25,.55,f));a=Math.max(a,te(p/v,f/.52,2.1))}return a}case"hoof":{let a=-1;for(let l=-1;l<=1;l+=2){const r=(o-.02)/.86,i=(t-l*.46)/.38+l*.28*r*r;a=Math.max(a,te(i,r,2.6))}return a}case"chitin":{const a=te(t/.42,(o-.32)/.5,1.7),l=te(t/.22,(o+.62)/.22,2);return Math.max(a,l)}case"pad":{const a=.9+.1*fe(-1,.3,o);let l=te(t/(.92*a),o/.95,2.8);for(let r=0;r<3;r++)l=Math.max(l,te((t-(r-1)*.5)/.26,(o-.8)/.3,2.4));return l}case"boot":default:{const a=(o-n.waistAt)/.42,l=1-n.waist*Math.exp(-a*a)+n.ball*fe(0,.75,o);return te(t/l,o,n.power)}}}function rl(e,t,o,n=0){const a=al(n),l=t+(se(t*4+3.1+a.nu,o*4+1.7+a.nv)-.5)*.11,r=o+(se(t*4+9.3+a.nu,o*4+5.2+a.nv)-.5)*.11,i=(l-re.cu)/re.ru,s=(r-re.cv)/re.rv,c=sl(e,i,s,a),h=se(t*8+a.nu,o*8+a.nv)*.6+se(t*22+a.nu,o*22+a.nv)*.4-.5;return c+h*.15}const Pe=20;function il(e,t,o,n=0){if(o>=-.02||o<=-.5)return 0;const a=Math.floor(e*Pe),l=Math.floor(t*Pe),r=.5+.5*fe(.3,.95,t);if(Le(a*3.7+11+n*13.7,l*2.3+5+n*9.1)>=.34*r)return 0;const i=(a+.5)/Pe,s=(l+.5)/Pe,c=Math.sqrt((e-i)*(e-i)+(t-s)*(t-s))*Pe;return Math.max(0,1-c*1.5)}function ll(e,t,o=0){const n=new Float32Array(M*M),a=new Float32Array(M*M);for(let l=0;l<M;l++)for(let r=0;r<M;r++){const i=l*M+r,s=(r+.5)/M,c=(l+.5)/M,h=rl(t,s,c,o);if(e==="wet"){const R=fe(0,.16,h);n[i]=-.35*R,a[i]=R;continue}const f=fe(-.08,k.wallEdge,h),p=(h+.07)/.075,v=Math.exp(-p*p),d=.35+.65*(se(s*13+2.5+o*41.3,c*13+6.5+o*23.7)*.7+se(s*31,c*31)*.3),g=v*d,E=il(s,c,h,o),_=(se(s*11,c*11)-.5)*.035*f,T=(se(s*24+5,c*24+9)-.5)*.2*v;n[i]=-f+g*.42+E*.26+_+T,a[i]=Math.min(1,f+g*.8+E*.9)}return{height:n,coverage:a}}function mo(){return M*da}function cl(){return M*fo.length}function hl(e,t,o){const n=Math.max(0,Re(o));for(let a=0;a<vt;a++)ul(e,t,o,a,a*M,n*M)}function ul(e,t,o,n,a,l){const{height:r,coverage:i}=ll(t,o,n),s=1/M,c=k.depth/(2*s*ma(o)),h=k.depth/(2*s*po()),f=mo(),p=(v,d)=>r[Math.min(M-1,Math.max(0,d))*M+Math.min(M-1,Math.max(0,v))];for(let v=0;v<M;v++)for(let d=0;d<M;d++){const g=v*M+d,E=(l+v)*f+(a+d),_=(p(d+1,v)-p(d-1,v))*c,T=(p(d,v+1)-p(d,v-1))*h,R=Math.sqrt(_*_+1+T*T),P=E*4;e[P]=Math.round(Math.min(1,Math.max(0,r[g]*.5+.5))*255),e[P+1]=Math.round(-_/R*.5*255+127.5),e[P+2]=Math.round(-T/R*.5*255+127.5),e[P+3]=Math.round(Math.min(1,i[g])*255)}}const ie=_t()!=="0",ga=`uniform float printCull;
`,fl=`
precision highp float;

attribute vec3 position;
attribute vec2 uv;

#ifdef INSTANCES
attribute vec4 world0;
attribute vec4 world1;
attribute vec4 world2;
attribute vec4 world3;
#endif

// NOT "color". Babylon rewrites a thin-instance colour buffer to the kind
// "instanceColor" on the way in (thinInstanceMesh.js: "color for instanced
// mesh is ColorInstanceKind and not ColorKind because of native"), so a shader
// declaring "color" binds nothing, gets the default (0,0,0,1), and draws every
// print as an opaque black hole. Babylon's own default shader knows this,
// which is why the StandardMaterial version did not show the bug.
#ifdef INSTANCESCOLOR
attribute vec4 instanceColor;
#endif

uniform mat4 world;
uniform mat4 viewProjection;
uniform vec3 cameraPosition;
// How much of the atlas one sole spans, per axis: 1/cols by 1/rows. The grid
// is not square any more (four variants across, one row per track shape), so
// this is a vec2 and not the single ATLAS_FILL it used to be.
uniform vec2 atlasSpan;
${ie?ga:""}
varying vec2 vUV;
varying vec4 vColor;
// Origin of this print's quarter of the sole atlas. The relief march has to be
// held inside it: an unclamped march walks straight into the neighbouring
// sole, and a print would sample the toe of a different boot along its edge.
varying vec2 vAtlas;
varying vec3 vTan;
varying vec3 vBit;
varying vec3 vNrm;
varying vec3 vView;

void main() {
#ifdef INSTANCES
  mat4 finalWorld = world * mat4(world0, world1, world2, world3);
#else
  mat4 finalWorld = world;
#endif

  vec4 worldPos = finalWorld * vec4(position, 1.0);

  // instanceColor is (atlas u, atlas v, brightness jitter, alpha). It used to
  // be (tint.rgb, alpha), but the tint was the same value for every instance
  // of a kind - a uniform's job - which left two channels free for this.
#ifdef INSTANCESCOLOR
  vColor = instanceColor;
  vAtlas = instanceColor.xy;
#else
  vColor = vec4(1.0);
  vAtlas = vec2(0.0);
#endif

  vUV = uv * atlasSpan + vAtlas;

  // The instance's own axes. Rotating the baked normal by these is what lets
  // every print be lit from the same sun however it is turned.
  vTan = normalize(finalWorld[0].xyz);
  vBit = normalize(finalWorld[2].xyz);
  // The quad is tilted onto the ground's slope, so "up" is its own Y column
  // rather than the world's.
  vNrm = normalize(finalWorld[1].xyz);
  vView = cameraPosition - worldPos.xyz;

  gl_Position = viewProjection * worldPos;${ie?`

#ifdef INSTANCESCOLOR
  // A dead ring slot keeps its last matrix at alpha 0. All four corners on one
  // point outside the clip volume drop it before it makes a fragment.
  if (printCull > 0.5 && instanceColor.a <= 0.0)
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif`:""}
}
`,dl=`
precision highp float;

varying vec2 vUV;
varying vec4 vColor;
varying vec2 vAtlas;
varying vec3 vTan;
varying vec3 vBit;
varying vec3 vNrm;
varying vec3 vView;

uniform sampler2D soleSampler;
uniform vec3 sunDir;
// Colour this kind of print tends toward at full depth. A uniform now: it was
// per-instance, and it was the same for every instance of a kind.
uniform vec3 soleTint;
// x: relief reach in uv, y: ao strength, z: ambient, w: rim gain.
// These are uniforms rather than GLSL constants so FOOTPRINT_TUNING can move
// them live without recompiling the effect.
uniform vec4 soleParams;
// 1 when the frame buffer holds linear values, 0 when it holds display ones.
// The blend multiplies whatever the terrain already wrote, so it has to know
// which of the two that is. Same signal the terrain keys its own decode on.
uniform float linearOut;
${ie?ga:""}
const int RELIEF_STEPS = 12;
const int SHADOW_STEPS = 6;

/**
 * How much of the atlas one sole spans, and half a texel of it - so a clamped
 * fetch cannot bilinearly pick up the sole next door. Both are uniforms now:
 * the atlas is a grid of variants by track shape and its size depends on how
 * many shapes the kind has.
 */
uniform vec2 atlasSpan;
uniform vec2 atlasEdge;

/**
 * Longest march allowed, as a fraction of ONE CELL.
 *
 * Measured in cell space rather than atlas space on purpose: it is a limit on
 * how far the ray may walk across the sole, and the sole is the cell.
 */
const float SWEEP_MAX = 0.45;

/** Hold a sample inside this print's own cell of the atlas. */
vec2 soleUV(vec2 p) {
  return clamp(p, vAtlas + atlasEdge, vAtlas + atlasSpan - atlasEdge);
}

/** Cap a march in cell space, then take it into the atlas' own scale. */
vec2 toAtlas(vec2 cell) {
  float len = length(cell);
  return (len > SWEEP_MAX ? cell * (SWEEP_MAX / len) : cell) * atlasSpan;
}

void main() {
  vec3 view = normalize(vView);

  // View in the print's own frame. The lateral part over the part along the
  // surface normal is how far across the texture the eye travels per unit of
  // depth.
  vec2 viewT = vec2(dot(view, vTan), dot(view, vBit));
  float viewUp = max(dot(view, vNrm), 0.08);

  // Cap it at what fits inside this sole.
  //
  // A march that leaves the sub-rect finds no sole out there, only the border
  // soleUV() clamps it to - and the border is outside the outline, so it
  // returns coverage 0 and the print silently disappears. That is a bad way to
  // fail, and an especially bad one because the sweep length depends on the
  // view angle and on the tilt of the ground under the print: it does not fail
  // everywhere, it fails on some prints some of the time, which reads as them
  // blinking in and out for no reason.
  //
  // Capping costs a little parallax at a grazing angle. That is the right
  // trade against losing the print altogether.
  vec2 sweep = toAtlas((viewT / viewUp) * soleParams.x);

  // Relief march: walk down through depth layers until the height field rises
  // above the ray. A single offset only shifts the picture; this hides the
  // near wall behind its own rim and brings the far wall into view.
  float layerStep = 1.0 / float(RELIEF_STEPS);
  vec2 uvStep = sweep * layerStep;

  // R is signed height biased to 0.5, so depth below the surface is
  // (1 - 2R) and height above it is (2R - 1).
  vec2 uv = vUV;
  float rayDepth = 0.0;
  float texDepth = max(0.0, 1.0 - 2.0 * texture2D(soleSampler, soleUV(uv)).r);

  for (int i = 0; i < RELIEF_STEPS; i++) {
    if (rayDepth >= texDepth) break;
    uv -= uvStep;
    texDepth = max(0.0, 1.0 - 2.0 * texture2D(soleSampler, soleUV(uv)).r);
    rayDepth += layerStep;
  }

  // One linear refinement between the last two layers, so the wall does not
  // come out in visible bands.
  vec2 prevUV = uv + uvStep;
  float after = texDepth - rayDepth;
  float before =
      max(0.0, 1.0 - 2.0 * texture2D(soleSampler, soleUV(prevUV)).r) -
      (rayDepth - layerStep);
  uv = soleUV(mix(uv, prevUV, clamp(after / (after - before + 1e-5), 0.0, 1.0)));

  vec4 sole = texture2D(soleSampler, uv);
  float signedHeight = sole.r * 2.0 - 1.0;
  float depth = max(0.0, -signedHeight);
  float coverage = sole.a;${ie?`

  // Strength 0 comes out as alpha 0 and add 0, which the premultiplied blend
  // leaves as it found it, and nothing here writes depth.
  if (printCull > 0.5 && coverage * vColor.a <= 0.0) discard;`:""}

  float nx = sole.g * 2.0 - 1.0;
  float nz = sole.b * 2.0 - 1.0;
  float ny = sqrt(max(0.0, 1.0 - nx * nx - nz * nz));
  vec3 normal = normalize(vTan * nx + vNrm * ny + vBit * nz);

  // Self-shadowing rim: march toward the sun and see whether the ridge the
  // boot pushed up gets in the way, so the rim lays a real shadow across the
  // inside of the print.
  vec2 lightT = vec2(dot(sunDir, vTan), dot(sunDir, vBit));
  float lightUp = max(dot(sunDir, vNrm), 0.08);
  // Capped the same way the view march is. Uncapped it walks out of the cell
  // at a grazing sun, and every sample then clamps to the border - which is
  // outside the outline and so reads as flat, undisturbed snow. Against a ray
  // that is below the surface that scores as fully blocked, so a print in a
  // low sun went dark for a reason that was entirely an artefact of the atlas.
  vec2 lightSweep = toAtlas((lightT / lightUp) * soleParams.x);

  float blocked = 0.0;
${ie?`
  // At depth 0 alongRay is 0, so no step can score above 0 and blocked stays 0.
  if (depth > 0.0) {`:""}
  for (int i = 1; i <= SHADOW_STEPS; i++) {
    float t = float(i) / float(SHADOW_STEPS);
    float alongRay = depth * (1.0 - t);
    float here = max(
      0.0,
      1.0 - 2.0 * texture2D(soleSampler, soleUV(uv + lightSweep * t)).r
    );
    blocked = max(blocked, (alongRay - here) * (1.0 - t));
  }${ie?`
  }`:""}

  // Smoothstepped and shallow: a hard cut here is what made the interior read
  // as one solid blob instead of a gradient running down the wall.
  float selfShadow = 1.0 - smoothstep(0.0, 1.0, blocked * 1.8) * 0.5;

  // Deliberately high. A print in snow is not a dark hole: snow is close to a
  // perfect diffuser and a cavity's walls bounce light into each other, so
  // even a wall turned right away from the sun keeps most of its brightness.
  // Depth is read from the *pairing* of a lit rim against a mid-tone floor,
  // which is why the rim below may add light. Dropping this is what turned an
  // earlier cut into black ovals.
  float ambient = soleParams.z;

  float lambert = max(dot(normal, sunDir), 0.0) * selfShadow;
  float lit = ambient + (1.0 - ambient) * lambert;
  float flatLit = ambient + (1.0 - ambient) * max(dot(vNrm, sunDir), 0.0);

  // How much of the ground survives, measured against what undisturbed snow
  // beside it would have caught. 1 means untouched.
  float keep = lit / max(0.08, flatLit) * (1.0 - soleParams.y * depth);

  // Snow the boot pushed up, above the original surface.
  float raised = max(0.0, signedHeight);

  // Rim light: the crest is tilted up into the sun and catches it square on,
  // which is the cue that says the snow was displaced rather than merely
  // pressed. This is additive, so it can go brighter than the snow beside it.
  float rim = raised * max(dot(normal, sunDir), 0.0) * soleParams.w;

  // Subsurface: snow is translucent, so light entering a thin displaced ridge
  // scatters through and leaves the far side glowing instead of going flat
  // dark. Keyed to the side facing away from the sun.
  // Subsurface rides at a little over half the rim: it is the same displaced
  // snow, seen from its unlit side.
  float sss = raised * max(0.0, -dot(normal, sunDir)) * soleParams.w * 0.55;

  vec3 tint = mix(vec3(1.0), soleTint, depth);

  // vColor.z is this print's own brightness, a small wobble either side of 1.
  // Four sole shapes stop a trail repeating its outline; this stops it
  // repeating its *weight*, which is the other half of what gives away a
  // stamped decal. Costs nothing - the channel was already there.
  float strength = coverage * vColor.a * vColor.z;

  // Premultiplied blend: dst * (1 - a) + rgb. The (1 - a) half is a
  // *proportional* darkening -- correct inside a shadow and on half-covered
  // ground, exactly as the multiply blend was -- and the rgb half adds light
  // on top, which multiply could never do. That is what buys the bright rim.
  //
  // There is only one alpha for three channels, and expressing a per-channel
  // tint through it would need to know what the ground already drew, which a
  // blend cannot tell us. So the *most* darkened channel goes through the
  // alpha, and the other two are handed back the difference as light. That is
  // exact where the ground is bright, which is the case this exists for (snow
  // at ~0.93); on darker stone it over-corrects the hue slightly, which is a
  // fair trade for one pass and no assumption about the surface.
  float floorTint = min(tint.r, min(tint.g, tint.b));
  float keepScalar = clamp(keep * floorTint, 0.0, 1.0);

  // How much of the ground survives, in DISPLAY space - the space every
  // number above was tuned in, and the space the buffer is in only when
  // post-processing is off.
  float keepShown = 1.0 - (1.0 - keepScalar) * strength;

  // With image processing in post the terrain writes pow(colour, 2.2)
  // (terrainMaterial's linearOut), so a factor applied there comes back as
  // its own 1/2.2 root once the frame is gamma-encoded again: a print tuned
  // to take a fifth off the snow took a tenth of it. That is the whole of
  // "the prints are barely there with post-processing on". Raising the factor
  // into the buffer's own domain is exact and needs nothing from the grade -
  // exposure and contrast hit the print and the snow beside it alike, so they
  // cancel out of the ratio.
  float alpha = 1.0 - mix(keepShown, pow(keepShown, 2.2), linearOut);

  vec3 hue = keep * (tint - vec3(floorTint)) * strength;

  // The additive half goes in as authored either way. Its linear equivalent
  // is the display add times the encode slope at the snow's own brightness
  // (~2.0 at 0.93) over the mood exposure (~2.1), and those two cancel to
  // within a few percent - unlike the multiply, which is out by a whole
  // gamma.
  vec3 add = hue + vec3(rim + sss) * strength;

  gl_FragColor = vec4(add, alpha);
}
`;function pl(e){const t=In(e)?.direction??new m(.4,-1,.6);return new m(-t.x,-t.y,-t.z).normalize()}const Ve=new Map;function va(e,t,o){if(e.baked.has(o)||Re(o)<0)return;e.baked.add(o);const n=Math.max(0,Re(o)),a=M*mo()*4,l=n*a,r=`${t}:${o}`,i=qt.get(r);i?e.data.set(i,l):(hl(e.data,t,o),qt.set(r,e.data.slice(l,l+a))),e.texture.update(e.data)}const qt=new Map;function uf(e,t,o){for(const n of o)Re(t)<0||(va(go(e,n),n,t),wa(e,n,"hero"))}function ml(e,t){return go(e,t).material}function go(e,t){const o=Ve.get(t);if(o&&o.material.getScene()===e)return o;const n=new Tr(`_footprints_${t}`,e,{vertexSource:fl,fragmentSource:dl},{attributes:["position","uv"],uniforms:["world","viewProjection","cameraPosition","sunDir","soleParams","soleTint","atlasSpan","atlasEdge","linearOut",...ie?["printCull"]:[]],samplers:["soleSampler"],needAlphaBlending:!0}),a=mo(),l=cl(),r=new Uint8Array(a*l*4),i=Xn.CreateRGBATexture(r,a,l,e,!1,!1,Ae.BILINEAR_SAMPLINGMODE);i.name=`footprintSole_${t}`,i.wrapU=Ae.CLAMP_ADDRESSMODE,i.wrapV=Ae.CLAMP_ADDRESSMODE,n.setTexture("soleSampler",i),n.setVector3("sunDir",pl(e)),n.setFloat("linearOut",At(e)?1:0);const s=Qi[t];n.setVector3("soleTint",new m(s[0],s[1],s[2]));const[c,h]=pa();n.setVector2("atlasSpan",new Ho(c,h)),n.setVector2("atlasEdge",new Ho(.5/a,.5/l)),n.setVector4("soleParams",new Mr(k.depth/po(),k.ao,k.ambient,k.rim)),n.backFaceCulling=!1,n.alphaMode=Zn.ALPHA_PREMULTIPLIED,n.disableDepthWrite=!0,n.zOffset=-8,ie&&gl(n),n.onDisposeObservable.addOnce(()=>i.dispose());const f={material:n,texture:i,data:r,baked:new Set};return Ve.set(t,f),f}function gl(e){const t=e.getScene().getEngine();e.onBindObservable.add(o=>{o.subMeshes[0]?.effect?.setFloat("printCull",t.getStencilBuffer()?0:1)})}function wa(e,t,o){const n=nl(t,o),a=Oe.get(n);if(a&&!a.mesh.isDisposed()&&a.mesh.getScene()===e)return a;const l=ji[o],r=Rr(`_footprints_${t}_${o}`,{size:1},e);r.rotation.x=Math.PI/2,r.bakeCurrentTransformIntoVertices(),r.isPickable=!1,r.alwaysSelectAsActiveMesh=!0,r.doNotSyncBoundingInfo=!0;const i=new Float32Array(l*16),s=new Float32Array(l*4),c=[];for(let f=0;f<l;f++)c.push({age:-1,life:1,strength:0,kind:t,shape:"boot",matrix:Or.Identity(),atlasU:0,atlasV:0,shade:1});r.thinInstanceSetBuffer("matrix",i,16,!1),r.thinInstanceSetBuffer("color",s,4,!1),r.thinInstanceCount=l,r.material=ml(e,t),r.setEnabled(!1);const h={mesh:r,matrixData:i,colourData:s,prints:c,size:l,next:0,dirty:!0};return Oe.set(n,h),h}const Jo=.22;function vl(e,t,o,n,a,l){for(let r=0;r<e.size;r++){const i=e.prints[r];if(i.age<0||i.kind!==t||i.shape!==o)continue;const s=i.matrix.m,c=s[12]-n,h=s[14]-a;if(!(c*c+h*h>Jo*Jo))return i.age=0,i.strength=Math.min(1,i.strength+l*.5),e.dirty=!0,!0}return!1}function wl(e,t,o,n,a,l,r,i,s,c,h){if(vl(e,t,o,n,l,c))return;const f=e.prints[e.next];e.next=(e.next+1)%e.size,f.age=0,f.life=tl[t],f.strength=Math.min(1,c),f.kind=t,f.shape=o;const p=Math.floor(Math.random()*vt)%vt,[v,d]=Xi(t,o,p);f.atlasU=v,f.atlasV=d,f.shade=.86+Math.random()*.28,r+=(Math.random()-.5)*.26,i*=.93+Math.random()*.14,s*=.93+Math.random()*.14;const g=Math.hypot(h.x,h.y,h.z)||1,E=h.x/g,_=h.y/g,T=h.z/g;let R=Math.sin(r),P=0,ee=Math.cos(r);const Se=R*E+P*_+ee*T;R-=E*Se,P-=_*Se,ee-=T*Se;const Ne=Math.hypot(R,P,ee)||1;R/=Ne,P/=Ne,ee/=Ne;const $t=_*ee-T*P,ns=T*R-E*ee,as=E*P-_*R,D=f.matrix.m;D[0]=$t*i,D[1]=ns*i,D[2]=as*i,D[3]=0,D[4]=E,D[5]=_,D[6]=T,D[7]=0,D[8]=R*s,D[9]=P*s,D[10]=ee*s,D[11]=0,D[12]=n+E*It,D[13]=a+_*It,D[14]=l+T*It,D[15]=1,f.matrix.markAsUpdated(),e.dirty=!0}function ff(e,t){const{kind:o,shape:n,strength:a}=t;if(a<=0||Re(n)<0)return;const l=t.scale??1;va(go(e,o),o,n),wl(wa(e,o,t.lane??"crowd"),o,n,t.x,t.y,t.z,t.angle,ma(n)*l,po()*l,a,t.up??ol)}function df(e){for(const t of Ve.values())t.material.setFloat("linearOut",At(t.material.getScene())?1:0);for(const t of Oe.values()){const{prints:o,matrixData:n,colourData:a}=t;let l=0;for(let r=0;r<t.size;r++){const i=o[r],s=r*4;if(i.age<0){a[s+3]=0;continue}if(i.age+=e,i.age>=i.life){i.age=-1,a[s+3]=0,t.dirty=!0;continue}l++;const c=i.age/i.life,h=c<=1-Zo?1:Math.max(0,(1-c)/Zo);n.set(i.matrix.asArray(),r*16),a[s]=i.atlasU,a[s+1]=i.atlasV,a[s+2]=i.shade,a[s+3]=el[i.kind]*i.strength*h,t.dirty=!0}t.mesh.setEnabled(l>0),t.dirty&&(t.dirty=!1,t.mesh.thinInstanceBufferUpdated("matrix"),t.mesh.thinInstanceBufferUpdated("color"))}}function Sl(){for(const e of Oe.values()){for(const t of e.prints)t.age=-1;e.next=0,e.colourData.fill(0),e.mesh.setEnabled(!1),e.mesh.thinInstanceBufferUpdated("color"),e.dirty=!1}}function Qo(){for(const e of Oe.values())e.mesh.dispose();Oe.clear();for(const e of Ve.values())e.material.dispose();Ve.clear(),qt.clear()}const en={...k,tint:[...k.tint]};typeof window<"u"&&(window.muFootprints={get:()=>({...k}),set(e){return Object.assign(k,e),Qo(),{...k}},reset(){return Object.assign(k,en,{tint:[...en.tint]}),Qo(),{...k}}});const yl={name:"footprints",reset:Sl},bl=9,El=160;let ae=null,St=null,vo=!1;function Ll(e){if(ae&&ae.getScene()===e)return ae;ae&&Sa(),St=new m;const t=new Go("snowSpray",El,e);return t.emitter=St,t.isLocal=!1,t.blendMode=Go.BLENDMODE_STANDARD,t.minEmitBox=new m(-.06,0,-.06),t.maxEmitBox=new m(.06,.05,.06),t.direction1=new m(-.6,1,-.6),t.direction2=new m(.6,1.6,.6),t.minEmitPower=.5,t.maxEmitPower=1.6,t.gravity=new m(0,-7,0),t.minLifeTime=.3,t.maxLifeTime=.65,t.minSize=.045,t.maxSize=.1,t.minAngularSpeed=-4,t.maxAngularSpeed=4,t.color1=new he(1,1,1,.9),t.color2=new he(.93,.96,1,.75),t.colorDead=new he(.93,.96,1,0),t.addColorGradient(0,new he(1,1,1,0)),t.addColorGradient(.2,new he(1,1,1,.9)),t.addColorGradient(.65,new he(.95,.97,1,.7)),t.addColorGradient(1,new he(.93,.96,1,0)),t.forceDepthWrite=!1,t.emitRate=0,t.manualEmitCount=0,is(e,"World3/leaf01.OZT").then(o=>{ae===t&&(t.particleTexture=o,vo=!0)}).catch(ls("World3/leaf01.OZT")),t.start(),ae=t,t}function xl(e,t,o,n,a){if(a<=0||!J.advancedEffects)return;const l=Ll(e);if(!vo)return;St?.set(t,o,n);const r=Math.max(1,Math.round(bl*Math.min(1,a)));l.manualEmitCount=Math.max(0,l.manualEmitCount)+r}function Sa(){ae?.dispose(!1),ae=null,St=null,vo=!1}const Al={name:"snowSpray",reset:Sa},$e=8,yt=.35,_l=5,Tl=28,Ml=.8,Rl=.25,tn=4,ya=.45,Ol=.2,Cl=.12,kl=.07,de=Array.from({length:$e},()=>({x:0,z:0,radius:0,age:0,strength:0})),ye=new Array($e*4).fill(0);let ba=$e;function bt(e){const t=e-yt-_l;return t<=0?1:Math.max(0,1-t/Tl)}function Ea(e){return e<yt?e/yt:bt(e)}function $l(e,t,o){const n=Math.min(1,Math.max(0,(o-e)/(t-e)));return n*n*(3-2*n)}function Il(e,t,o,n=1){if(o<=0||n<=0)return;for(const r of de){if(r.strength<=0)continue;const i=e-r.x,s=t-r.z;if(!(Math.sqrt(i*i+s*s)>r.radius*Ml)){r.radius=Math.min(tn,Math.max(r.radius,o)+Rl),r.strength=Math.max(r.strength,n),r.age=Math.min(r.age,yt);return}}let a=de[0],l=a.strength*bt(a.age);for(const r of de){const i=r.strength*bt(r.age);i<l&&(a=r,l=i)}a.x=e,a.z=t,a.radius=Math.min(tn,o),a.strength=n,a.age=0}function Dl(e,t){let o=0;for(const n of de){if(n.strength<=0)continue;const a=e-n.x,l=t-n.z,r=Math.sqrt(a*a+l*l)/n.radius;if(r>=1)continue;const i=n.strength*Ea(n.age)*(1-$l(ya,1,r));i>o&&(o=i)}return o}function Nl(e,t=!1){let o=0;for(let n=0;n<$e;n++){const a=de[n],l=e?a.strength*Ea(a.age):0,r=l>0?l:0;if(t&&r===0)continue;const i=o++*4;ye[i]=a.x,ye[i+1]=a.z,ye[i+2]=a.radius,ye[i+3]=r}return ye.fill(0,o*4),ba=o,ye}function Pl(){return ba}function zl(e,t){for(const o of de)o.strength<=0||(o.age+=t,bt(o.age)<=0&&(o.strength=0))}function Hl(){for(const e of de)e.strength=0,e.radius=0,e.age=0}const Gl={name:"snowMelt",update:zl,reset:Hl},Fl={lum:[.62,.85],chroma:[.16,.34]},on=.85,Ul=1.1,pe=8,Ye=_t()!=="0",jt={groundLightLoop:`    for (int i = 0; i < ${pe}; i++) {
      vec4 gl = groundLightPos[i];
      float gd = length(vWorldXZ - gl.xy);
      float gf = max(0.0, (gl.z - gd) / max(gl.z, 0.001));
      dynLight += groundLightCol[i].rgb * pow(gf, gl.w) * linearLight * roomParams.y;
    }`,groundSum:`    vec3 bakeLit = mix(bake, pow(bake, vec3(2.2)), linearLight) * roomParams.z;
    vec3 groundLight = max(bakeLit + dynLight, vec3(0.0));
    float peak = max(groundLight.r, max(groundLight.g, groundLight.b));
    float bent = peak > GROUND_CEIL_KNEE
      ? GROUND_CEIL_KNEE + GROUND_CEIL_ROOM * (1.0 - exp(-(peak - GROUND_CEIL_KNEE) / GROUND_CEIL_ROOM))
      : peak;
    vec3 softCeil = peak > 0.0 ? groundLight * (bent / peak) : groundLight;
    groundLight = mix(min(groundLight, vec3(1.0)), softCeil, linearLight);`,groundEncode:`    vec3 groundLit = mix(groundLight, pow(groundLight, vec3(1.0 / 2.2)), linearLight);
    vec3 extraLit = mix(dynLight, pow(dynLight * keyGain, vec3(1.0 / 2.2)), linearLight);`},pf=["time","linearOut","linearLight","keyGain","roomParams","groundLightPos","groundLightCol",so,Dn,...cs];function mf(e){return["dynamicLight",...e?[gs]:[]]}const gf=["csmShadowMap","csmShadowMapF"];function vf(){return[...ps(),...ms()]}function wf(e){return`
  uniform float time;
  uniform float linearOut;
  uniform float linearLight;
  uniform float keyGain;
  uniform float ${so};
  uniform vec3 roomParams; // x: a room is the active area, y: gain on the delta (AreaLook.candles), z: the room's share of the key on the bake
  uniform sampler2D dynamicLight;
  // The pool's slots on the ground: xy the tile position, z the footprint
  // radius (0: empty slot), w the falloff exponent; the colour carries the
  // floor gain, the fade and the dynamic gain.
  uniform vec4 groundLightPos[${pe}];
  uniform vec4 groundLightCol[${pe}];
  uniform vec4 ${Dn}; // x mip bias, y tone levels, z grass outline darkness, w its width in pixels

  const float GROUND_CEIL_KNEE = ${on.toFixed(3)};
  const float GROUND_CEIL_ROOM = ${(Ul-on).toFixed(3)};

${hs()}
${us()}
${e?fs():""}

  ${ds()}
`}function Sf(){return`
    // One fetch, two jobs: rgb is the torches' radial light, and alpha is the
    // roof mask the ground overlays need (terrainMask.ts). Sampled before the
    // overlay so skyOpen is in scope for it.
    vec4 dynSample = texture2D(dynamicLight, (vWorldXZ + 0.5) / 256.0);
    vec3 dynLight = dynSample.rgb * 2.0 * roomParams.y;
    float skyOpen = dynSample.a;

    // Tiers >= 1: the lights the pool holds, per pixel, with the same
    // footprint the tile map would have stamped for them - the stamp is one
    // texel a tile, and on a dark floor its bilinear skirt read as tile
    // squares. The tile map above carries only what the pool does not hold.
${Ye?`    // Branches on uniforms: a whole draw takes one side, so Classic
    // skips the loop, and an empty slot (range 0) would add exactly nothing.
    if (linearLight > 0.5) {
      for (int i = 0; i < ${pe}; i++) {
        vec4 gl = groundLightPos[i];
        if (gl.z <= 0.0) continue;
        float gd = length(vWorldXZ - gl.xy);
        float gf = max(0.0, (gl.z - gd) / max(gl.z, 0.001));
        dynLight += groundLightCol[i].rgb * pow(gf, gl.w) * roomParams.y;
      }
    }`:jt.groundLightLoop}
`}function yf(e){return`
    // The sun's cascaded shadow, weighted by the openness mask: both
    // interiors take their roof *out* of the shadow map on purpose so the
    // camera can see in (Lorencia lifts HOUSE_WALL05/06 past the caster
    // range, Devias fades its ceiling), so under a roof the cascades are not
    // the authority and the bake keeps the room it was authored for - until
    // the room itself is the active area (roomShadow): then its furniture
    // and figures cast on the floor under the roof as well.
    float sunShadow = mix(1.0, csmShadow(vWorldPos, vViewZ), max(skyOpen, roomParams.x));

    // A cloud takes the sun and leaves the sky share, the same one rule, on
    // the same openness mask the cascades use: a floor under a roof takes no
    // cloud shadow.
${e.clouds?"    sunShadow *= mix(1.0, muCloudShadow(vWorldPos), skyOpen);":""}

    // The one shadow rule: a shadow removes the sun and leaves the sky share
    // (csmParams.y, the policy floor). 1 while Classic (no cascades).
    float bakeShadow = mix(csmParams.y, 1.0, sunShadow);

    // The ground light sum. Tiers >= 1 (linearLight): lin(bake) + delta, the
    // delta linear-authored and added after the decode. Classic: the
    // original's gamma-space bake + delta (ZzzLodTerrain.cpp:481-505),
    // untouched. The bake is the ground's key: inside a room it takes the
    // room's share of the level and the delta, the candles, does not (§13 F14).
    vec3 bake = max(${e.bake}, vec3(0.0));
${Ye?`    vec3 groundLight;

    // The original clamps glColor at 1.0 per channel. Tiers >= 1 bend the
    // sum toward the asymptote above the knee so a torch core keeps its hue.
    if (linearLight > 0.5) {
      vec3 bakeLit = pow(bake, vec3(2.2)) * roomParams.z;
      groundLight = max(bakeLit + dynLight, vec3(0.0));
      float peak = max(groundLight.r, max(groundLight.g, groundLight.b));
      float bent = peak > GROUND_CEIL_KNEE
        ? GROUND_CEIL_KNEE + GROUND_CEIL_ROOM * (1.0 - exp(-(peak - GROUND_CEIL_KNEE) / GROUND_CEIL_ROOM))
        : peak;
      groundLight = peak > 0.0 ? groundLight * (bent / peak) : groundLight;
    } else {
      groundLight = min(max(bake * roomParams.z + dynLight, vec3(0.0)), vec3(1.0));
    }`:jt.groundSum}

    // The cascades cut the ceiled sum, not the bake under it (§13 F15): on
    // open ground the ceiling compresses lit and shadowed alike, so a factor
    // applied before it left a fraction of the policy's ratio. 1 on Classic.
    groundLight *= bakeShadow;

    // The map's level (2^ev) is the light's, applied after the clamps so
    // they keep the original's units; 1.0 on Classic.
    groundLight *= keyGain;

    // The overlays and the reflections below work in the art's display
    // space; the linear sum is re-encoded for them and the final decode
    // lands the product exactly at lin(texel) x groundLight.
${Ye?`    vec3 groundLit = groundLight;
    vec3 extraLit = dynLight;

    if (linearLight > 0.5) {
      groundLit = pow(groundLight, vec3(1.0 / 2.2));
      extraLit = pow(dynLight * keyGain, vec3(1.0 / 2.2));
    }`:jt.groundEncode}
`}function bf(e){return Ye?`    if (linearOut > 0.5) ${e} = pow(max(${e}, vec3(0.0)), vec3(2.2));`:`    ${e} = mix(${e}, pow(max(${e}, vec3(0.0)), vec3(2.2)), linearOut);`}let La=Date.now();function Ef(){La=Date.now()}function Wl(){return(Date.now()-La)/1e3}function Lf(e,t,o){e.setFloat("time",Wl()),e.setFloat("linearOut",At(t)?1:0),e.setFloat("linearLight",vs(t)?1:0);const n=Nn()?.state();e.setFloat("keyGain",n?.key.sceneGain??1),e.setFloat3("roomParams",n?.area?1:0,n?.key.emitterGain??1,n?.key.roomShare??1),e.setFloat(so,ws()),Ss(e),o&&(nt.base=n?.profile.sky?n.profile.sky.clouds??ys:null,nt.sunDirection=n?.key.direction??xa,nt.sunElevationDeg=n?.profile.sun.elevationDeg??45,bs(e,t,nt)),e.setTexture("dynamicLight",Es(t));const a=Ls();for(let l=0;l<pe;l++){const r=a[l],i=l*4;ze[i]=r?r.x:0,ze[i+1]=r?r.z:0,ze[i+2]=r?r.range:0,ze[i+3]=r?r.falloff:1,He[i]=r?r.r:0,He[i+1]=r?r.g:0,He[i+2]=r?r.b:0,He[i+3]=0}e.setArray4("groundLightPos",ze),e.setArray4("groundLightCol",He),xs(e)}const xa=[0,-1,0],nt={base:null,sunDirection:xa,sunElevationDeg:45},ze=new Array(pe*4).fill(0),He=new Array(pe*4).fill(0),Ge={shadow:[.6,.63,.7],lit:[.86,.88,.92],cap:.95,gain:1.3},nn={name:"snowCover",colour:[.985,.98,.965],blend:"mix",coverage:Tt,lightNeutral:1,headroom:.25,bed:{0:1,1:1,2:1,7:1,4:.55,6:.55,5:0},bedDefault:.3,defersToArt:Fl,patchScale:.14,softness:.12,slopeKnee:.45,slopeTop:.72,outdoorOnly:!0,grain:.035,grainScale:.9,relief:1,reliefScale:.16,melt:!0},Aa={name:"wetGround",colour:[.63,.65,.7],blend:"multiply",coverage:ua,bed:{5:0},bedDefault:1,patchScale:.06,softness:.3,slopeKnee:.45,outdoorOnly:!0},_a={name:"puddles",colour:[.5,.53,.6],blend:"multiply",coverage:()=>Math.min(.42,fa()*.55),patchScale:.34,softness:.045,slopeKnee:.985,outdoorOnly:!0,bed:{5:0},bedDefault:1,reflect:{sky:1,gloss:48,ripple:.35}},Z={relief:.55,cavity:.35,sheen:.08,grain:.003,depth:0},Bl={...Z};typeof window<"u"&&(window.muSnow={get:()=>({...Z}),cover:()=>Tt(),set(e){return Object.assign(Z,e),{...Z}},reset(){return Object.assign(Z,Bl),{...Z}}});let an=null,at=new m(-.4,1,-.6).normalize();function Ta(e){if(e===an)return at;const t=In(e);if(!t)return at;const o=t.direction;return an=e,at=new m(-o.x,-o.y,-o.z).normalize(),at}function st(e,t){const o=i=>i-Math.floor(i);let n=o(e*.1031),a=o(t*.1031),l=o(e*.1031);const r=n*(a+33.33)+a*(l+33.33)+l*(n+33.33);return n+=r,a+=r,l+=r,o((n+a)*l)}function sn(e,t){const o=Math.floor(e),n=Math.floor(t);let a=e-o,l=t-n;a=a*a*(3-2*a),l=l*l*(3-2*l);const r=st(o,n),i=st(o+1,n),s=st(o,n+1),c=st(o+1,n+1);return(r+(i-r)*a)*(1-l)+(s+(c-s)*a)*l}function rn(e,t,o,n,a){const l=e.coverage();if(l<=0)return 0;e.outdoorOnly;const r=t*e.patchScale,i=o*e.patchScale,s=sn(r,i)*.65+sn(r*2.7,i*2.7)*.35,c=e.slopeKnee,h=e.slopeTop??1;let f=(Math.min(1,Math.max(0,n))-c)/(h-c);f=Math.min(1,Math.max(0,f)),f=f*f*(3-2*f);const p=Math.min(1,l)*(1+(e.headroom??0))*f,v=s-e.softness,d=s+e.softness;let g=(p-v)/(d-v);return g=Math.min(1,Math.max(0,g)),g*g*(3-2*g)}function ln(e,t){return e.bed?e.bed[t]??e.bedDefault??1:1}function wo(e){for(let t=0;t<e.length;t++)if(e[t].melt)return!0;return!1}function ce(e){for(let t=0;t<e.length;t++)if(e[t].relief)return!0;return!1}function ne(e){for(let t=0;t<e.length;t++)if(e[t].reflect)return!0;return!1}const Ce=6,Fe=7,rt=.02,cn=.12,Kl=1.4,Vl=2.2,Yl=.35,ql=5,jl=1.5,Xl=.25,Zl=12,Jl=.05,hn=.6,Ql=.44,ec=.74,tc=1.55,oc=.6,nc=8,ac=1.6,sc=1.63,rc=.9,un=.44,fn=.18,ic=.28,lc=.04,cc=2.2,hc={wetGround:Aa,puddles:_a},dn=new WeakMap;function uc(e){const t=Ze.layerFor(e)?.terrain?.overlays;if(!t)return;let o=dn.get(t);return o||(o=t.map(n=>hc[n]),dn.set(t,o)),o}const Dt=[],pn=new Map;function Ma(e){const t=Ze.layerFor(e)?.terrain?.snowBed;if(!t)return nn;let o=pn.get(e);return o||(o={...nn,bed:t},pn.set(e,o)),o}function fc(e){if(!J.advancedEffects)return Dt;const t=uc(e);return Pn.has(e)?[...t??Dt,Ma(e)]:t??Dt}function xf(e){return fc(e).some(t=>t.outdoorOnly)}function Af(e){const t=e.map((o,n)=>`ovCoverage${n}`);return wo(e)&&(t.push("ovMeltSpot"),qe&&t.push("ovMeltCount")),ce(e)&&t.push("ovSunDir","ovShade","ovGrain","cameraPosition"),ne(e)&&(ce(e)||t.push("ovSunDir","cameraPosition"),t.push("ovSky","ovSkyHi","ovRipple","ovRain","ovLightPos","ovLightCol")),t}function u(e){return Number.isInteger(e)?`${e}.0`:`${e}`}const Nt=.2,Pt=[.63,.65,.7],qe=_t()!=="0",dc=1,pc=.55,mc="vec3(0.72, 0.75, 0.83)",mn=12,gc=.35,gn=.62,vn=.2,vc=150,wc=.978,Sc=3,Xt=.819,Zt=.574,zt=.014,yc=10,bc=26,Ec=30,Lc=55;function _f(e,t,o){if(e.length===0)return"";const n=e.map((i,s)=>{const c=i.colour,h=i.blend==="multiply"?`${t}.rgb * vec3(${u(c[0])}, ${u(c[1])}, ${u(c[2])})`:`vec3(${u(c[0])}, ${u(c[1])}, ${u(c[2])})`,f=i.defersToArt?`
      float ovArt${s} = ovArtMatch(
        ${t}.rgb,
        vec2(${u(i.defersToArt.lum[0])}, ${u(i.defersToArt.lum[1])}),
        vec2(${u(i.defersToArt.chroma[0])}, ${u(i.defersToArt.chroma[1])}));
      ovCol${s} = mix(ovCol${s}, ${t}.rgb, ovArt${s});
`:"",p=i.grain??0,v=i.grainScale??1,d=p>0&&!i.relief?`
      // Surface of the layer itself: two octaves of the same noise, as a
      // brightness wobble either side of 1. Drifts, not patches.
      float ovG${s} =
          overlayNoise(vWorldXZ * ${u(v)}) * 0.6 +
          overlayNoise(vWorldXZ * ${u(v*3.1)}) * 0.4;
      ovCol${s} *= 1.0 + ${u(p)} * (ovG${s} - 0.5) * 2.0;
`:"",g=i.relief?`
      // ---- the layer's own surface ---------------------------------------
      //
      // Depth, which is not ovAmount. Amount saturates once the ground has
      // gone white; depth keeps climbing past that, and the gap between the
      // two is the difference between "the ground is white here" and "there
      // is a drift here". Deepest where the break-up noise is low, which is
      // where snow collects.
      float ovDepth${s} = ovAmount${s} * clamp(
        0.35 + (ovTarget${s} - ovBreakup${s}) + ovShade.w, 0.0, 1.0);

      float ovHc${s} = ovRelief${s}(vWorldXZ);

      // Albedo wobble, off the surface rather than off a field of its own.
      ovCol${s} *= 1.0 + ${u(i.grain??0)} * (ovHc${s} - 0.5) * 2.0;
      float ovHx${s} = ovRelief${s}(vWorldXZ + vec2(${u(Nt)}, 0.0));
      float ovHz${s} = ovRelief${s}(vWorldXZ + vec2(0.0, ${u(Nt)}));

      // Gradient of that field, as a surface normal, blended toward the
      // ground's own by depth: a dusting follows the terrain, a drift has a
      // shape of its own.
      //
      // The blend treats the bump as if the ground were level and so
      // under-rotates on a slope. Affordable because slopeKnee fades the
      // layer out well before the ground is steep enough for that to show.
      // Procedural noise has no mip chain, so past the distance at which a
      // drift is narrower than a pixel the gradient stops being a surface and
      // becomes shimmer. Fade the *detail* out with range while leaving depth
      // alone, because depth also decides coverage and distant snow should
      // still be snow - just flat snow, which is what it was before this
      // existed and is exactly what it should degrade to.
      //
      // This also carries the failure mode for cameraPosition: unbound it
      // reads as the origin, the distance becomes the fragment's own distance
      // from world zero, and every terrain fragment on a 256-tile map lands
      // past the far end of the fade. An unbound uniform switches the feature
      // off rather than lighting the map from an arbitrary place.
      vec3 ovEye${s} = cameraPosition - vWorldPos;
      float ovDetail${s} = ovDepth${s} *
        (1.0 - smoothstep(${u(Ec)}, ${u(Lc)}, length(ovEye${s})));

      float ovGain${s} = ovShade.x * ${u(i.relief)} / ${u(Nt)};

      // Crystal grain, on its own step because it is on its own scale. Fades
      // out far sooner than the drifts do: a 0.11-tile feature falls under a
      // pixel much closer to the camera than a 3-tile one, and past that point
      // it stops being texture and starts being shimmer.
      float ovGc${s} = ovGrainAt${s}(vWorldXZ);
      float ovGx${s} = ovGrainAt${s}(vWorldXZ + vec2(${u(zt)}, 0.0));
      float ovGz${s} = ovGrainAt${s}(vWorldXZ + vec2(0.0, ${u(zt)}));
      float ovGg${s} = ovGrain * ovDepth${s} / ${u(zt)} *
        (1.0 - smoothstep(${u(yc)}, ${u(bc)}, length(ovEye${s})));

      vec3 ovBump${s} = normalize(vec3(
        -(ovHx${s} - ovHc${s}) * ovGain${s} - (ovGx${s} - ovGc${s}) * ovGg${s},
        1.0,
        -(ovHz${s} - ovHc${s}) * ovGain${s} - (ovGz${s} - ovGc${s}) * ovGg${s}
      ));
      // The snow's own normal, built WITHOUT reference to vNormal.
      //
      // The mix that used to be here dragged the terrain's normal into the
      // snow's lighting, and that normal is flat per tile: the ground is a
      // quad soup with four unshared vertices each, so every tile is a facet.
      // Under a texture nobody notices; under a smooth white layer the facets
      // become the dominant structure and the snowfield reads as a grid of
      // slightly different squares - a large part of what kept coming back as
      // "pixelated". The bake still carries the terrain's real shape, which is
      // where that belongs.
      float ovNmix${s} = ovDetail${s};
      vec3 ovN${s} = normalize(vec3(
        ovBump${s}.x * ovNmix${s},
        1.0,
        ovBump${s}.z * ovNmix${s}
      ));

      // Sun on that normal, folded into the albedo rather than added after
      // the fact, so the drift is still cut by the cascades and still coloured
      // by the map's own bake - a drift in the shade of a wall is a shaded
      // drift. That is the whole reason this belongs in the terrain shader and
      // not in a decal.
      //
      // What shades is the DEVIATION from the ground's own normal, not the
      // absolute dot product. Two reasons, and the first one is why the drifts
      // did not show up at all on the first attempt:
      //
      //  - On near-level ground dot(vNormal, sun) is about 0.81 and the
      //    perturbation is worth about 0.09 either side of it. An absolute
      //    term therefore spends nine tenths of its range on a constant and
      //    one tenth on the shape it exists to show. Centring it hands the
      //    whole range to the shape.
      //  - The constant part is a flat brightening of every snow fragment,
      //    which is the bake's job and not this term's. Worse, it disappears
      //    at the far end of the detail fade, so distant snow would read
      //    dimmer than near snow with a visible band between them.
      // Centred on level ground rather than on vNormal, for the same reason.
      float ovNdl${s} = dot(ovN${s}, ovSunDir) - ovSunDir.y;
      ovCol${s} *= max(
        1.0 + ${u(dc)} * ovNdl${s} * ovSunOn * ovNmix${s},
        ${u(pc)});

      // Troughs between drifts lose sky. What they lose is the warm direct
      // sun, so what is left is cooler than the lit face - a tint rather than
      // a plain darkening, which is the same reasoning as the footprints'
      // cavity colour and keeps the two agreeing on one map.
      // Only the genuine troughs. The band used to open at 0.2, which is most
      // of a field whose height runs 0..1 - so the tint was washing over
      // roughly half the snow instead of sitting in the hollows of it.
      float ovCav${s} = (1.0 - smoothstep(0.42, 0.95, ovHc${s})) * ovDetail${s};
      ovCol${s} *= mix(
        vec3(1.0), ${mc}, clamp(ovShade.y * ovCav${s}, 0.0, 1.0));

      // Sheen, in two parts, because snow scatters at two scales at once.
      //
      // The first version of this was a single tight pow(NdotH, 42), and
      // that is precisely the "polished glass" read: an isotropic lobe that
      // narrow puts ONE sharp highlight on a surface which in reality throws
      // light along its ripples. Snow is rough and directional, and the lobe
      // has to be too.
      vec3 ovView${s} = normalize(ovEye${s});
      vec3 ovHalf${s} = normalize(ovView${s} + ovSunDir);

      // Ward-style anisotropic lobe about the wind axis: broad ALONG the
      // ripple, tight across it. Same axis the grain is stretched on, so the
      // sheen elongates in the direction the surface actually runs.
      vec3 ovWindT${s} = normalize(vec3(${u(Xt)}, 0.0, ${u(Zt)}));
      vec3 ovWindB${s} = normalize(cross(ovN${s}, ovWindT${s}));
      float ovHt${s} = dot(ovHalf${s}, ovWindT${s});
      float ovHb${s} = dot(ovHalf${s}, ovWindB${s});
      float ovHn${s} = max(dot(ovHalf${s}, ovN${s}), 0.0001);
      float ovWard${s} = exp(-(
        ovHt${s} * ovHt${s} / ${u(gn*gn)} +
        ovHb${s} * ovHb${s} / ${u(vn*vn)}
      ) / (ovHn${s} * ovHn${s}));

      // Glitter: individual crystals catching the sun, and the reason they
      // twinkle is that each one is tilted its own way. A sparse hash picks
      // which cells fire and a second pair gives each its OWN micro-normal, so
      // a glint lights only while the half-vector happens to meet that facet -
      // it comes and goes as the camera moves. Firing them all off the surface
      // normal, as the earlier cut did, just puts static white dots on the
      // ground.
      vec2 ovCell${s} = floor(vWorldXZ * ${u(vc)});
      vec3 ovFacet${s} = normalize(vec3(
        overlayHash(ovCell${s} + 3.1) - 0.5,
        0.55,
        overlayHash(ovCell${s} + 7.7) - 0.5
      ));
      float ovGlint${s} =
        step(${u(wc)}, overlayHash(ovCell${s})) *
        pow(max(dot(ovFacet${s}, ovHalf${s}), 0.0), 90.0);

      // Both gated on ovSunOn - an unbound sun direction must not be allowed
      // to put a highlight in an arbitrary place.
      ovCol${s} += vec3(ovWard${s} + ovGlint${s} * ${u(Sc)}) *
                   ovShade.z * ovSunOn * ovDetail${s};

      // Thin snow settles INTO the ground's texture instead of hiding it,
      // which is what lets paving read through at the fringe rather than the
      // layer stopping at a clean edge. Last, so everything above sees the
      // unmodulated amount.
      //
      // The blend runs on a SMOOTHSTEP of depth, not on depth itself, and the
      // difference matters more than it looks. Against raw depth the term
      // never quite reaches 1: at full coverage depth still sits around 0.65
      // in places, which left up to a sixth of the ground texture showing
      // through a snowfield that should have been opaque. The ground texture
      // is a tile magnified across several world units, so what came through
      // was not a hint of stone - it was visible texels. Reaching 1 by a
      // depth of 0.45 confines this to genuinely thin snow, which is the only
      // place it was ever meant to fire.
      ovAmount${s} = clamp(
        ovAmount${s} * mix(
          0.3 + 1.2 * ovHc${s}, 1.0, smoothstep(0.0, 0.45, ovDepth${s})),
        0.0, 1.0);
`:"",E=i.melt?`
      float ovMelt${s} = 0.0;
      for (int m = 0; m < ${$e}; m++) {${qe?`
        if (float(m) >= ovMeltCount) break;`:""}
        float ovMr${s} = max(ovMeltSpot[m].z, 0.001);
        vec2 ovMv${s} = vWorldXZ - ovMeltSpot[m].xy;

        // The patch's own outline rather than a circle. A disc is the one
        // shape that reads as stamped instead of melted, and a fire skill
        // worked over a snowfield left a row of identical coins.
        //
        // The phases are hashed out of the spot's own position, so a patch
        // holds its shape for as long as it lives and no two are alike -
        // without a byte more uniform, because the bearing is the only thing
        // this needs and the loop was already taking the distance.
        float ovMs${s} = fract(
          sin(dot(ovMeltSpot[m].xy, vec2(12.9898, 78.233))) * 43758.5453
        ) * 6.2831853;
        float ovMa${s} = atan(ovMv${s}.y, ovMv${s}.x);
        float ovMk${s} = 1.0
          + ${u(Ol)} * sin(ovMa${s} * 2.0 + ovMs${s})
          + ${u(Cl)} * sin(ovMa${s} * 3.0 + ovMs${s} * 1.7)
          + ${u(kl)} * sin(ovMa${s} * 5.0 + ovMs${s} * 2.3);

        float ovMd${s} = length(ovMv${s}) / (ovMr${s} * ovMk${s});
        ovMelt${s} = max(
          ovMelt${s},
          ovMeltSpot[m].w * (1.0 - smoothstep(${u(ya)}, 1.0, ovMd${s})));
      }
`:"",_=i.melt?`
      ${t}.rgb *= mix(
        vec3(1.0),
        vec3(${u(Pt[0])}, ${u(Pt[1])}, ${u(Pt[2])}),
        ovMelt${s});`:"";return`
    // Layer ${s}: ${i.name} (${i.blend}) - see terrainOverlay.ts.
    if (ovCoverage${s} > 0.0) {
      // Two octaves of value noise decide WHERE the layer lands. Thresholding
      // it against the coverage is what makes the layer creep outward from
      // patches as it builds, instead of the whole ground fading up together.
      vec2 ovP${s} = vWorldXZ * ${u(i.patchScale)};
      float ovBreakup${s} =
          overlayNoise(ovP${s}) * 0.65 + overlayNoise(ovP${s} * 2.7) * 0.35;
${E}
      // Melt divides the TARGET, not the finished amount: everything the
      // layer has - its coverage, its depth, the drifts' relief and lighting -
      // hangs off this one number, so taking
      // it down here is the difference between snow that was burned away and
      // snow that has been painted over.
      float ovTarget${s} =
          ovCoverage${s} * ${u(1+(i.headroom??0))} * ${i.outdoorOnly?o:"1.0"} * ovFlat(${u(i.slopeKnee)}, ${u(i.slopeTop??1)})${i.bed?` * ovBedHere${s}`:""}${i.melt?` * (1.0 - ovMelt${s})`:""};

      float ovAmount${s} = smoothstep(
        ovBreakup${s} - ${u(i.softness)},
        ovBreakup${s} + ${u(i.softness)},
        ovTarget${s}
      );

      vec3 ovCol${s} = ${h};
${f}${d}${g}
      ${t}.rgb = mix(${t}.rgb, ovCol${s}, ovAmount${s});${_}${i.reflect?`
      ovWater = max(ovWater, ovAmount${s});`:""}${i.lightNeutral?`
      ovNeutral = max(ovNeutral, ovAmount${s} * ${u(i.lightNeutral)});`:""}
    }`}),a=Ra(e)?`    float ovNeutral = 0.0;
`:"",l=(ce(e)||ne(e)?`    float ovSunOn = step(0.5, dot(ovSunDir, ovSunDir));
`:"")+(ne(e)?`    float ovWater = 0.0;
`:""),r=e.map((i,s)=>i.bed?`    float ovBedHere${s} = mix(ovBed${s}(int(m1)), ovBed${s}(int(m2)), alphaRendered ? vAlphaColor.a : 0.0);
`:"").join("");return a+r+l+n.join(`
`)}function Ra(e){for(let t=0;t<e.length;t++)if(e[t].lightNeutral)return!0;return!1}function Tf(e,t,o,n,a,l){if(!Ra(e))return`    vec3 ${t} = ${o};`;const r=Ge.shadow,i=Ge.lit,s=p=>`vec3(${u(p[0]**2.2)}, ${u(p[1]**2.2)}, ${u(p[2]**2.2)})`,c=`min(
          mix(vec3(${u(r[0])}, ${u(r[1])}, ${u(r[2])}),
              vec3(${u(i[0])}, ${u(i[1])}, ${u(i[2])}), ovKey) + ovExtra,
          vec3(${u(Ge.cap)}))`,h=`min(
          mix(${s(r)}, ${s(i)}, ovKey) + pow(ovExtra, vec3(2.2)),
          vec3(${u(Ge.cap**2.2)}))`,f=Ye?`
      vec3 ovLayerLit;
      if (linearLight > 0.5) {
        vec3 ovLayerLin = ${h};
        ovLayerLit = pow(ovLayerLin, vec3(1.0 / 2.2));
      } else {
        ovLayerLit = ${c};
      }`:`
      vec3 ovLayerLit =
        ${c};
      vec3 ovLayerLin =
        ${h};
      ovLayerLit = mix(ovLayerLit, pow(ovLayerLin, vec3(1.0 / 2.2)), linearLight);`;return`
    vec3 ${t} = ${o};
    {
      float ovBakeLum = dot(${n}.rgb, vec3(0.299, 0.587, 0.114));
      float ovKey = smoothstep(0.0, 1.0, ovBakeLum * ${u(Ge.gain)}) * ${a};
      vec3 ovExtra = max(${l}, vec3(0.0));${f}
      ${t} = mix(${t}, ovLayerLit, ovNeutral);
    }`}function Mf(e){if(e.length===0)return"";const t=[...e.map((i,s)=>`  uniform float ovCoverage${s};`),...wo(e)?[`  uniform vec4 ovMeltSpot[${$e}];`,...qe?["  uniform float ovMeltCount;"]:[]]:[]].join(`
`),o=[...ce(e)||ne(e)?["  uniform vec3 ovSunDir;","  uniform vec3 cameraPosition;"]:[],...ce(e)?["  uniform vec4 ovShade;","  uniform float ovGrain;"]:[],...ne(e)?["  uniform vec3 ovSky;","  uniform vec3 ovSkyHi;","  uniform float ovRipple;","  uniform float ovRain;",`  uniform vec4 ovLightPos[${Ce}];`,`  uniform vec3 ovLightCol[${Ce}];`]:[]].join(`
`),n=ce(e)||ne(e)?`
  vec2 ovGrad(vec2 i) {
    // Two hashes into a direction. No trig: normalize of a square-distributed
    // pair is cheaper than a sin/cos pair and the slight bias toward the
    // diagonals disappears once the octaves are summed. The epsilon keeps
    // normalize away from a zero vector on the one lattice point where both
    // hashes land on 0.5.
    vec2 g = vec2(overlayHash(i), overlayHash(i + 17.17)) * 2.0 - 1.0;
    return g / max(length(g), 0.0001);
  }

  float ovGnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = p - i;
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = dot(ovGrad(i), f);
    float b = dot(ovGrad(i + vec2(1.0, 0.0)), f - vec2(1.0, 0.0));
    float c = dot(ovGrad(i + vec2(0.0, 1.0)), f - vec2(0.0, 1.0));
    float d = dot(ovGrad(i + vec2(1.0, 1.0)), f - vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y) * 0.7 + 0.5;
  }`:"",a=ne(e)?`
  vec2 ovRingGrad(vec2 p, float t, float salt, float density) {
    vec2 cell = floor(p);

    // Each cell keeps its own phase, so the field does not pulse in unison.
    float k = t / ${u(rc)} + overlayHash(cell + salt);
    float period = floor(k);
    float u = k - period;

    // Re-rolled every period: whether this cell carries a drop at all, and
    // where in the cell it lands. Without the re-roll the same cells would
    // ring forever and the density could not follow the rain.
    vec2 id = cell + vec2(period * 37.0 + salt, period * 17.0 - salt);
    if (overlayHash(id) > density) return vec2(0.0);

    vec2 c = cell + vec2(0.3) +
      0.4 * vec2(overlayHash(id + 5.5), overlayHash(id + 9.1));
    vec2 d = p - c;
    float r = length(d);
    if (r < 0.0001) return vec2(0.0);

    // Signed distance from the crest, in crest widths. Compact support: one
    // trough and one crest, nothing outside |x| < 1, which is what keeps the
    // ring inside its own cell.
    float front = u * ${u(un)};
    float x = (r - front) / ${u(fn)};
    if (abs(x) >= 1.0) return vec2(0.0);

    // h(x) = sin(pi x) (1 - x^2); the derivative is the product rule of it.
    float w = 1.0 - x * x;
    float dh = (3.14159265 * cos(3.14159265 * x) * w -
      2.0 * x * sin(3.14159265 * x)) / ${u(fn)};

    // Flattens as it spreads, and is gone before the cell edge.
    float amp = (1.0 - u) * (1.0 - u) *
      (1.0 - smoothstep(${u(ic)}, ${u(un)}, r));

    return (d / r) * dh * amp;
  }`:"",l=e.map((i,s)=>{if(!i.relief)return"";const c=i.reliefScale??1;return`
  // Layer ${s} crystal grain: ONE octave, far finer than the drift field, and
  // deliberately kept out of ovRelief so the drift's gradient step does not
  // have to resolve it. Sampling a 0.11-tile period with the drift's 0.2 step
  // would measure nothing but its own aliasing.
  //
  // ANISOTROPIC, and that is the point of it. Undisturbed powder is not
  // covered in round specks - the wind works it into ripples, long in the
  // direction it blew and tight across, and that streaking is most of what
  // separates a snowfield from a noisy white surface. Rotating into the wind
  // axis and then sampling at two very different frequencies gets it for the
  // cost of a 2x2 multiply: low frequency along the wind stretches a feature
  // out, high frequency across it keeps the ripple tight.
  float ovGrainAt${s}(vec2 p) {
    vec2 w = vec2(
      p.x * ${u(Xt)} - p.y * ${u(Zt)},
      p.x * ${u(Zt)} + p.y * ${u(Xt)}
    );
    return ovGnoise(vec2(
      w.x * ${u(mn*gc)},
      w.y * ${u(mn)}
    ));
  }

  float ovRelief${s}(vec2 p) {
    vec2 q = p * ${u(c)};
    float n = ovGnoise(q) * 0.66;
    q = vec2(q.x * 0.8 - q.y * 0.6, q.x * 0.6 + q.y * 0.8) * 2.13;
    n += ovGnoise(q) * 0.23;
    q = vec2(q.x * 0.8 - q.y * 0.6, q.x * 0.6 + q.y * 0.8) * 2.31;
    return n + ovGnoise(q) * 0.11;
  }`}).join(""),r=e.map((i,s)=>{if(!i.bed)return"";const c=Object.entries(i.bed).map(([h,f])=>`    if (t == ${h}) return ${u(f)};`).join(`
`);return`
  float ovBed${s}(int t) {
${c}
    return ${u(i.bedDefault??1)};
  }`}).join("");return`
${t}
${o}
${r}

  // Every caller of this hashes an INTEGER: the noise lattice hashes
  // floor(p), and the glitter hashes floor(worldXZ * scale). The hash that
  // used to be here could not survive that.
  //
  //     p = fract(p * vec2(127.1, 311.7));
  //
  // For integer x, fract(127.1 * x) is fract(0.1 * x) - ten values, and the
  // same ten for y. So the final mix only ever saw a 10x10 grid of inputs.
  // Measured over a 300x300 patch of lattice: 55 DISTINCT OUTPUTS out of
  // 90000 points, and not one of them above 0.978.
  //
  // Two consequences, both of which had been costing us for a while. Every
  // noise field here - patch placement, drifts, grain - was drawing its values
  // from a set of 55, which is a repeating pattern wearing a noise function's
  // clothes. And any threshold up in the tail, which is how sparse effects
  // like glitter are selected, could never fire at all: it was dead code from
  // the day it was written.
  //
  // This is Hoskins' hash21. On the same lattice: 86136 distinct outputs of
  // 90000, and 2.15% above 0.978 against the 2.2% a uniform hash owes.
  float overlayHash(vec2 p) {
    vec3 p3 = fract(vec3(p.x, p.y, p.x) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }

  float overlayNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(overlayHash(i), overlayHash(i + vec2(1.0, 0.0)), f.x),
      mix(overlayHash(i + vec2(0.0, 1.0)), overlayHash(i + vec2(1.0, 1.0)), f.x),
      f.y
    );
  }

  // How much this albedo already IS a layer's own substance: bright, and
  // without the colour that separates blue ice or standing water from snow.
  // The CPU twin is artMatch in terrainOverlay.ts; keep them in step.
  float ovArtMatch(vec3 c, vec2 lumRamp, vec2 chromaRamp) {
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float chroma = mx > 0.0 ? (mx - mn) / mx : 0.0;
    float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));
    return smoothstep(lumRamp.x, lumRamp.y, lum) *
           (1.0 - smoothstep(chromaRamp.x, chromaRamp.y, chroma));
  }

  // How level this fragment is, against a layer's slope limit.
  // Full by top, not by 1.0: the ground normal is flat per tile, so a
  // ramp that only saturates on dead-level ground leaves every mildly
  // sloped tile half-covered - hard tile-shaped holes across a hillside.
  float ovFlat(float knee, float top) {
    return smoothstep(knee, top, clamp(vNormal.y, 0.0, 1.0));
  }
${n}
${a}
${l}
  `}function Rf(e,t,o){const n=J.advancedEffects;for(let l=0;l<t.length;l++){const r=n?t[l].coverage():0;e.setFloat(`ovCoverage${l}`,r>0?Math.min(1,r):0)}if(wo(t)&&(e.setArray4("ovMeltSpot",Nl(n,qe)),qe&&e.setFloat("ovMeltCount",Pl())),ne(t)&&xc(e,t,o,n),!ce(t))return;const a=Ta(o);e.setFloat3("ovSunDir",a.x,a.y,a.z),e.setFloat("ovGrain",n?Z.grain:0),e.setFloat4("ovShade",n?Z.relief:0,n?Z.cavity:0,n?Z.sheen:0,n?Z.depth:0)}function Of(e,t,o){if(!ne(e))return"";const a=e.find(l=>l.reflect).reflect;return`
    // ---- standing water (terrainOverlayReflectGlsl) ---------------------
    if (ovWater > 0.0 && ovSunOn > 0.0) {
      vec3 ovV = normalize(cameraPosition - vWorldPos);

      vec2 ovRp = vWorldXZ * ${u(Fe)};
      vec2 ovR1 = ovRp + vec2(time * 0.7, time * 0.45);
      vec2 ovR2 = ovRp * 2.3 + vec2(-time * 1.1, time * 0.8);
      float ovRh = ovGnoise(ovR1) + 0.5 * ovGnoise(ovR2);
      float ovRhx = ovGnoise(ovR1 + vec2(${u(rt*Fe)}, 0.0)) +
        0.5 * ovGnoise(ovR2 + vec2(${u(rt*Fe*2.3)}, 0.0));
      float ovRhz = ovGnoise(ovR1 + vec2(0.0, ${u(rt*Fe)})) +
        0.5 * ovGnoise(ovR2 + vec2(0.0, ${u(rt*Fe*2.3)}));
      // The gradient is already Δh over one step of the field; dividing by
      // the raw step here scaled it ~17x and tipped every normal nearly
      // horizontal - the whole pool lit up as mottled foil. 3.0 puts the slope at ~0.3 with full rain on a
      // ripple-0.35 recipe: shivering glints, readable water.
      float ovRk = ovRipple * 3.0;
      vec2 ovSlope = vec2(-(ovRhx - ovRh) * ovRk, -(ovRhz - ovRh) * ovRk);

      // The rain landing on the pool. Two ring layers at cell sizes that
      // share no multiple, so the lattice of neither is visible.
      if (ovRain > 0.0) {
        float ovDensity = min(1.0, ovRain * ${u(cc)});
        vec2 ovRingP = vWorldXZ * ${u(ac)};
        vec2 ovRings =
          ovRingGrad(ovRingP, time, 0.0, ovDensity) +
          0.7 * ovRingGrad(
            ovRingP * ${u(sc)} + 37.0, time * 1.17, 91.0, ovDensity);
        ovSlope -= ovRings * (ovRain * ${u(lc)});
      }

      vec3 ovWn = normalize(vec3(ovSlope.x, 1.0, ovSlope.y));

      float ovCosV = max(dot(ovWn, ovV), 0.0);
      float ovF = ${u(cn)} + (1.0 - ${u(cn)}) * pow(1.0 - ovCosV, 5.0);

      // ---- the sky in the water ----
      //
      // The mirrored view ray. Steep at the far edge of a pool, grazing at
      // the near one, and shivering wherever a ring crosses it - so every
      // term below varies across the water instead of washing it.
      vec3 ovRay = reflect(-ovV, ovWn);
      float ovUp = clamp(ovRay.y, 0.0, 1.0);
      vec3 ovSkyCol = mix(ovSky, ovSkyHi, pow(ovUp, ${u(jl)}));

      // Where that ray meets the cloud deck. Dividing by the ray's elevation
      // is the parallax: a grazing ray travels much further before it gets
      // there, so the deck stretches toward the near edge of the pool and
      // swims when the camera moves.
      vec2 ovDeck = vWorldXZ + ovRay.xz * (${u(Zl)} / max(ovRay.y, 0.08));
      vec2 ovCloudP =
        (ovDeck + vec2(time * ${u(hn)}, time * ${u(hn*.6)})) *
        ${u(Jl)};
      float ovCloud =
        ovGnoise(ovCloudP) * 0.62 + ovGnoise(ovCloudP * 2.7 + 13.0) * 0.38;
      // Only where the water is actually showing sky: a near-horizontal ray
      // is looking at the far ground, and putting clouds there is what a
      // scrolling texture would do.
      ovCloud = smoothstep(${u(Ql)}, ${u(ec)}, ovCloud) * ovUp;
      ovSkyCol *= mix(1.0, ${u(tc)}, ovCloud);

      vec3 ovRefl = ovSkyCol * ${u(a.sky)} * ovF;

      // The sun, cut by its own shadow so a puddle under a wall stays dark.
      //
      // The halo is the bright patch of SKY around the sun, so it is tested
      // on the mirrored ray - where the water is looking - and not on the
      // half vector. On a near-level pool the half vector barely changes
      // across the whole surface, so a halo built on it is another flat
      // wash; on the ray it swings with the ripple and slides as you walk,
      // which is the point of having it at all.
      ovRefl += ovSkyCol *
        pow(max(dot(ovRay, ovSunDir), 0.0), ${u(nc)}) *
        ${u(oc)} * ${o} * max(ovF, 0.25);

      // The pin-point glint stays on the half vector: that one is a
      // specular highlight on the surface, not a piece of sky.
      vec3 ovH = normalize(ovV + ovSunDir);
      ovRefl += vec3(1.0) * pow(max(dot(ovWn, ovH), 0.0), ${u(a.gloss)}) *
        ${u(Kl)} * ${o} * max(ovF, 0.25);

      // The torches: a glint and, under it, the smeared glow of the flame.
      for (int i = 0; i < ${Ce}; i++) {
        vec3 ovL = ovLightPos[i].xyz - vWorldPos;
        float ovD = length(ovL);
        ovL /= max(ovD, 0.001);
        float ovAtt = max(0.0, 1.0 - ovD / max(ovLightPos[i].w, 0.001));
        ovAtt *= ovAtt;
        vec3 ovLh = normalize(ovV + ovL);
        float ovNdh = max(dot(ovWn, ovLh), 0.0);
        ovRefl += ovLightCol[i] * ovAtt * (
          pow(ovNdh, ${u(a.gloss)}) * ${u(Vl)} +
          pow(ovNdh, ${u(ql)}) * ${u(Yl)}
        ) * max(ovF, 0.25);
      }

      // Bounded: three torches and the sun on one grazing fragment must
      // bloom, not white the pool out.
      ${t} += min(ovRefl, vec3(1.5)) * ovWater;
    }
`}function xc(e,t,o,n){if(!ce(t)){const d=Ta(o);e.setFloat3("ovSunDir",d.x,d.y,d.z)}const a=Nn()?.state(),l=At(o),r=d=>l?Math.pow(Math.max(d,0),1/2.2):d,i=a&&a.profile.fog.density>0?a.fogColorLinear:null,s=o.clearColor,c=i?[r(i[0]),r(i[1]),r(i[2])]:[r(s.r),r(s.g),r(s.b)];e.setFloat3("ovSky",n?c[0]:0,n?c[1]:0,n?c[2]:0);const h=a?.key;for(let d=0;d<3;d++){const g=h?h.skyColor[d]*h.skyIntensity:0;lt[d]=n?Math.min(g,c[d]*(1-Xl)):0}e.setFloat3("ovSkyHi",lt[0],lt[1],lt[2]);const f=t.find(d=>d.reflect),p=uo();e.setFloat("ovRipple",n?p*f.reflect.ripple:0),e.setFloat("ovRain",n?p:0);const v=As();for(let d=0;d<Ce;d++){const g=v[d],E=n&&g&&g.intensity>0?g.intensity:0;Ue[d*4]=g?g.position.x:0,Ue[d*4+1]=g?g.position.y:0,Ue[d*4+2]=g?g.position.z:0,Ue[d*4+3]=g?g.range:0,it[d*3]=g?g.diffuse.r*E:0,it[d*3+1]=g?g.diffuse.g*E:0,it[d*3+2]=g?g.diffuse.b*E:0}e.setArray4("ovLightPos",Ue),e.setArray3("ovLightCol",it)}const Ue=new Array(Ce*4).fill(0),it=new Array(Ce*3).fill(0),lt=[0,0,0],Ht=.12,Ac=.55,_c=.35,We={layer1:0,layer2:255,alpha:0};function Tc(e,t,o){e.getTerrainLayers(~~t,~~o,We);const n=Ma(e.mapIndex),a=ln(n,We.layer1);if(We.alpha<=0)return a;const l=ln(n,We.layer2);return a+(l-a)*We.alpha}function Oa(e,t,o){const n=t-.5,a=o-.5,l=Math.floor(n),r=Math.floor(a),i=n-l,s=a-r;let c=0;for(let f=0;f<4;f++){const p=l+(f&1),v=r+(f>>1),g=zn(p+.5,v+.5)?Tc(e,p,v):0,E=(f&1?i:1-i)*(f>>1?s:1-s);c+=g*E}const h=Dl(t,o);return h>0?c*(1-h):c}function Mc(e,t,o,n){const a=e.getTerrainHeight(t,n);return a<=-9e3?!1:o-a<=_c}function Rc(e,t,o,n,a){if(!J.weatherEffects||!J.advancedEffects)return 0;const l=Tt();if(l<=Ht||!Mc(e,o,n,a))return 0;const r=Oa(e,o,a);if(r<=0)return 0;const i=Math.min(1,(l-Ht)/(Ac-Ht));return k.depth*k.sink*i*r}const Oc={name:"snowSink",maps:Pn},I=4,$=256*I,Cc=300,kc=1,$c=6,Ic=.55,Dc=26,Nc=7,Pc=2.5,wn=8,Ca=_t()!=="0",zc=.5/I,Hc=.1,Gc=.22,Fc=1,Sn=5,Uc={...Hn,size:.03,sizeJitter:.012,life:.9,power:.7,gravity:-1.2},So=.22,yo=.13,bo=.08,yn=1+So+yo+bo,Wc=1-So-yo-bo,bn=255,Mt=e=>(e.x0=$,e.z0=$,e.x1=-1,e.z1=-1,e),we=e=>e.x1<e.x0||e.z1<e.z0,je=(e,t,o,n,a)=>{t<e.x0&&(e.x0=t),o<e.z0&&(e.z0=o),n>e.x1&&(e.x1=n),a>e.z1&&(e.z1=a)};function Eo(e,t){return 1+So*Math.sin(t*2+e.p1)+yo*Math.sin(t*3+e.p2)+bo*Math.sin(t*5+e.p3)}const H=[];let V=null,ct=new Uint8Array(0),U=null,Be=0,pt=0,Lo=null;const oe=Mt({x0:0,z0:0,x1:0,z1:0}),x=Mt({x0:0,z0:0,x1:0,z1:0});let Jt=null;function Cf(e){Jt=e}const Rt=(e,t)=>!Jt||Jt(e,t);let Qt=null;function kf(e){Qt=e}const Bc=(e,t)=>Qt?Qt(e,t):0;function ka(){return V||(V=new Uint8Array($*$)),V}function $f(e){return U&&U.getScene()===e||(U=Xn.CreateRTexture(ka(),$,$,e,!1,!1,Ae.BILINEAR_SAMPLINGMODE,Zn.TEXTURETYPE_UNSIGNED_INT),U.name="grassBurn",U.wrapU=Ae.CLAMP_ADDRESSMODE,U.wrapV=Ae.CLAMP_ADDRESSMODE,U.onDisposeObservable.addOnce(()=>{U=null}),we(x)||je(oe,x.x0,x.z0,x.x1,x.z1)),U}function If(){return!we(x)||H.length>0}function Kc(e,t){if(!V)return 0;const o=Math.floor(e*I),n=Math.floor(t*I);return o<0||n<0||o>=$||n>=$?0:V[n*$+o]/255}function ht(e,t,o,n,a,l,r){const i=(a+.5)/I,s=i-t.z,c=a*$;let h=!1;for(let f=l;f<=r;f++){const p=(f+.5)/I,v=p-t.x,d=v*v+s*s,g=Eo(t,Math.atan2(s,v)),E=(o*g)**2,_=(n*g)**2;if(d<E||d>_||!Rt(p,i))continue;const T=c+f;e[T]>=bn||(e[T]=bn,h=!0)}return h}function $a(e,t,o){const n=ka(),a=o*yn,l=Math.max(0,Math.floor((e.x-a)*I)),r=Math.min($-1,Math.ceil((e.x+a)*I)),i=Math.max(0,Math.floor((e.z-a)*I)),s=Math.min($-1,Math.ceil((e.z+a)*I));if(r<l||s<i)return;let c=!1;if(Ca){const h=o*yn+1/I,f=t*Wc-1/I,p=h*h,v=f>0?f*f:0;for(let d=i;d<=s;d++){const g=(d+.5)/I-e.z,E=g*g;if(E>=p)continue;const _=Math.sqrt(p-E),T=Math.max(l,Math.floor((e.x-_)*I)),R=Math.min(r,Math.ceil((e.x+_)*I));if(E<v){const P=Math.sqrt(v-E),ee=Math.ceil((e.x-P)*I),Se=Math.floor((e.x+P)*I)-1;if(ee<=Se){const Ne=ht(n,e,t,o,d,T,Math.min(R,ee-1)),$t=ht(n,e,t,o,d,Math.max(T,Se+1),R);(Ne||$t)&&(c=!0);continue}}ht(n,e,t,o,d,T,R)&&(c=!0)}}else for(let h=i;h<=s;h++)ht(n,e,t,o,h,l,r)&&(c=!0);c&&(je(oe,l,i,r,s),je(x,l,i,r,s))}function eo(e){e.radius>e.burnt&&($a(e,e.burnt,e.radius),e.burnt=e.radius),e.sinceStamp=0}const Vc=e=>we(x)||e.radius-e.burnt>=zc||e.sinceStamp>=Hc;function Yc(e){for(let t=0;t<wn;t++){const o=t/wn*Math.PI*2,n=e.radius*Eo(e,o);if(Rt(e.x+Math.cos(o)*n,e.z+Math.sin(o)*n))return!0}return!1}function qc(e,t,o,n,a=1){if(!J.advancedEffects||!Rt(t,o))return;Lo=e;for(const r of H)if(Math.hypot(r.x-t,r.z-o)<=r.radius){r.vigour=Math.max(r.vigour,a);return}const l={x:t,z:o,radius:n,burnt:0,vigour:a,sinceEmber:0,sinceStamp:0,p1:Math.random()*Math.PI*2,p2:Math.random()*Math.PI*2,p3:Math.random()*Math.PI*2};if(H.length>=$c){let r=0;for(let i=1;i<H.length;i++)H[i].vigour<H[r].vigour&&(r=i);eo(H[r]),H.splice(r,1)}$a(l,0,n),l.burnt=n,H.push(l)}const jc=new m;function Xc(e,t){const o=Lo;if(o&&(e.sinceEmber+=t,!(e.sinceEmber<Gc))){e.sinceEmber=0;for(let n=0;n<Sn;n++){const a=(n+Math.random())/Sn*Math.PI*2,l=e.radius*Eo(e,a),r=e.x+Math.cos(a)*l,i=e.z+Math.sin(a)*l;if(!Rt(r,i))continue;const s=jc;s.x=r,s.y=Bc(r,i),s.z=i,S.spawn("particles",o,s,{recipe:Uc,count:Fc})}}}function Zc(e){if(!V||we(x))return;const{x0:t,z0:o,x1:n,z1:a}=x;je(oe,t,o,n,a);let l=$,r=$,i=-1,s=-1;for(let c=o;c<=a;c++){const h=c*$;for(let f=t;f<=n;f++){const p=h+f,v=V[p];if(v===0)continue;const d=v>e?v-e:0;V[p]=d,d!==0&&(f<l&&(l=f),f>i&&(i=f),c<r&&(r=c),c>s&&(s=c))}}x.x0=l,x.z0=r,x.x1=i,x.z1=s}function Jc(e,t,o){const n=e&-4,a=Math.min(o-1,t|3);return[n,a-n+1]}function Ia(){if(we(oe)||!U||!V)return;const e=U.getInternalTexture(),t=U.getScene()?.getEngine();if(!e||!t||!e.isReady)return;const[o,n]=Jc(oe.x0,oe.x1,$),{z0:a,z1:l}=oe,r=l-a+1;ct.length<n*r&&(ct=new Uint8Array(n*r));for(let i=0;i<r;i++){const s=(a+i)*$+o;ct.set(V.subarray(s,s+n),i*n)}t.updateTextureData(e,ct.subarray(0,n*r),o,a,n,r),Mt(oe)}function Qc(e){for(let t=H.length-1;t>=0;t--){const o=H[t];o.radius+=Ic*o.vigour*e,o.vigour-=e*o.radius/Dc,Yc(o)||(o.vigour-=e*Pc);const n=o.vigour<=0||o.radius>=Nc;o.sinceStamp+=e,(!Ca||n||Vc(o))&&eo(o),Xc(o,e),n&&H.splice(t,1)}if(!we(x)&&(Be+=e,Be>=kc)){for(const o of H)eo(o);pt+=255*Be/Cc,Be=0;const t=Math.floor(pt);t>=1&&(Zc(t),pt-=t)}Ia()}function eh(){if(H.length=0,Lo=null,V&&!we(x)){for(let e=x.z0;e<=x.z1;e++){const t=e*$;V.fill(0,t+x.x0,t+x.x1+1)}je(oe,x.x0,x.z0,x.x1,x.z1)}Mt(x),pt=0,Be=0,Ia()}const th={name:"grassBurn",update:(e,t)=>Qc(t),reset:eh},be=.5,oh=.45;function nh(e,t,o){if(!zn(t,o))return 0;const a=e.getTerrainHeight(t-be,o),l=e.getTerrainHeight(t+be,o),r=e.getTerrainHeight(t,o-be),i=e.getTerrainHeight(t,o+be);if(a<=-9e3||l<=-9e3||r<=-9e3||i<=-9e3)return 0;const s=(l-a)/(2*be),c=(i-r)/(2*be),h=1/Math.sqrt(1+s*s+c*c);return Math.max(rn(_a,t,o,h),rn(Aa,t,o,h)*oh)}const ah={name:"puddleUnderfoot"},sh=[zi,_s,Yi,yl,Al,Ts,Gl,Oc,th,ah];class rh{id="weather";layers=[...sh];register(t){return this.layers.push(t),()=>{const o=this.layers.indexOf(t);o>=0&&this.layers.splice(o,1)}}layersFor(t){return this.layers.filter(o=>!o.maps||o.maps.has(t))}update(t,o){for(const n of this.layers)n.update?.(t,o)}reset(){for(const t of this.layers)t.reset?.()}get rain(){return uo()}get snowCover(){return Tt()}snowCapAt(t,o){return Ms(t,o)}get wetness(){return ua()}get puddles(){return fa()}inPuddles(){return Ki()}puddleUnderfoot(t,o,n){return nh(t,o,n)}snowUnderfoot(t,o,n){return Oa(t,o,n)}snowSinkDepth(t,o,n,a,l){return Rc(t,o,n,a,l)}meltSnow(t,o,n,a=1){Il(t,o,n,a)}burnGrass(t,o,n,a,l=1){qc(t,o,n,a,l)}grassBurnAt(t,o){return Kc(t,o)}snowSpray(t,o,n,a,l){xl(t,o,n,a,l)}}const Da=new rh,Na=[0,30,45,60,90,120,144],ih=Na.length-1;function lh(e){return Na[Math.max(0,Math.min(ih,e))]??0}const ch=.1;class hh{fps=0;nextDue=0;lastDrawn=-1;due(t,o){if(o>0){const n=1e3/o;if(t<this.nextDue-1)return!1;this.nextDue=t-this.nextDue>n?t+n:this.nextDue+n}if(this.lastDrawn>=0&&t>this.lastDrawn){const n=1e3/(t-this.lastDrawn);this.fps=this.fps>0?this.fps+(n-this.fps)*ch:n}return this.lastDrawn=t,!0}}const uh=new hh,Gt=[{enter:2/3,leave:.85},{enter:.4,leave:.55}],fh=60,dh=500;function ph(e,t,o){if(!(e>0)||!(t>0))return o;const n=e/t;let a=o;for(a>0&&n>Gt[a-1].leave&&(a=a-1);a<Gt.length&&n<Gt[a].enter;)a=a+1;return a}let Ft=0,En=-1/0;function Pa(e){return e-En>=dh&&(En=e,Ft=ph(uh.fps,lh(J.fpsLimit)||fh,Ft)),Ft}function Df(e,t){return J.effectShedding&&!!e.playerAnimation&&!e.localPlayer&&Pa(t)>=2}const mh=100,gh=40,vh={},wh=[1,2,4],Ln=new WeakMap;let xn=-1/0,Ut=0;function xo(e,t,o){const n=!!e.playerAnimation&&!e.localPlayer;if(n&&!J.otherSkillEffects)return!1;const a=J.skillVisualBudget,l=n&&J.effectShedding?Pa(o):0;if(!a&&l===0)return!0;if(a){const r=Math.max(mh,(vh[t]??0)*1e3),i=Ln.get(e);if(i!==void 0&&o-i<r)return!1}if(n){if(o-xn>=1e3&&(xn=o,Ut=0),Ut>=gh/wh[l])return!1;Ut++}return Ln.set(e,o),!0}const Sh=()=>Lr("enhancedSkillEffects"),me=.04,L=e=>e*me,y=e=>e/100,tt=e=>e*25/100,Xe=1.1,B=.9,yh=37,za=tt(70),bh=.9,An=.35,Eh=14,Lh=15*Math.PI/180,Ie=e=>(t,o)=>S.spawn("sprite",o.scene,t,e),Q=e=>(t,o)=>S.spawn("particles",o.scene,t,e),xh=e=>(t,o)=>S.spawn("model",o.scene,t,e),Nf=e=>(t,o)=>S.spawn("model",o.scene,t,Os(e,o.caster)),De=e=>(t,o)=>S.spawn("ring",o.scene,t,e),Pf=(e,t)=>(o,n)=>(Sh()?t:e)(o,n),Y=(...e)=>(t,o)=>{for(const n of e)n(t,o)},Ao=(e,t=Xe)=>(o,n)=>e(A(n.caster,t,new m),n),Ot=(e,t,o,n=0)=>(a,l)=>{for(let r=0;r<t;r++){const i=r/t*Math.PI*2+Math.random(),s=o*(.3+Math.random()*.7),c=new m(a.x+Math.cos(i)*s,a.y,a.z+Math.sin(i)*s);n>0&&r>0?z(r*n,()=>e(c,l)):e(c,l)}},zf=(e,t,o,n=0)=>(a,l)=>{for(let r=0;r<t;r++){const i=r/t*Math.PI*2,s=new m(a.x+Math.cos(i)*o,a.y,a.z+Math.sin(i)*o);n>0&&r>0?z(r*n,()=>e(s,l)):e(s,l)}},Ah=(e,t)=>(o,n)=>{const a=o.clone();z(e,()=>t(a,n))},Hf=new Set;function _h(e,t){const o=e.modelObject;if(!o)return!1;const n=!!e.monsterAnimation||(e.skin??-1)>=0;return(t.clips?t.clips.has(o.CurrentAction):co.releasesOnKey(o.CurrentAction,n))&&o.actionFrame()>=(t.key??br)}function _o(e,t,o={}){const n=L(o.limit===void 0?qn:o.limit-1);if(!e.caster.modelObject){z(n,t);return}const a=N(),l=()=>{N()-a+1e-9>=n||_h(e.caster,o)?t():z(0,l)};z(me,l)}let to=-1/0,oo=!0;function Ha(e){if(!e.caster.localPlayer)return;const t=N();to=t,oo=!1,_o(e,()=>{to===t&&(oo=!0)})}function Gf(e){const t=()=>{oo||N()-to+1e-9>=L(qn)?e():z(0,t)};t()}const Ff=(e,t)=>(o,n)=>{const a=o.clone(),l=G;_o(n,()=>{G=l,e(a,n)},t)},Uf=(e,t,o)=>(n,a)=>{for(let l=0;l<e;l++){const r=n.clone();l===0?o(r,a):z(l*t,()=>o(r,a))}},Ct=e=>({x:Math.sin(e),z:-Math.cos(e)}),Wf=(e,t,o=0,n=0)=>(a,l)=>{const r=Ct(ge(l.caster)),i=new m(a.x+r.x*t-r.z*n,a.y+o,a.z+r.z*t+r.x*n);e(i,l)},Bf=(e,t=0)=>{const o=Ct(ge(e.caster)+t);return new m(o.x,0,o.z)},Th=(e,t)=>{const o=new m(t.x-e.x,0,t.z-e.z);return o.lengthSquared()>1e-6?o.normalize():new m(0,0,1)},Kf=(e,t,o,n,a)=>{const l=N();return r=>{const i=a+n*(N()-l);return A(e,o,r),r.x+=Math.cos(i)*t,r.z+=Math.sin(i)*t,r}},Vf=e=>t=>Gn(e,yh,t,Xe),To=e=>Mi(e,ve.world?.mapIndex??-1),Ga=(e=b.steel,t=w.swordBlur,o=bh)=>(n,a)=>{const l=N(),r=(i,s)=>c=>{const h=Math.min(1,(N()-l)/An),f=Ct(ge(a.caster)+(h-.5)*(Math.PI*2)/3);return A(a.caster,i+(.5-h)*.4,c),c.x+=f.x*s,c.z+=f.z*s,c};S.spawn("blur",a.scene,m.Zero(),{follow:r(1.1,o),base:r(.9,o*.35),colour:e,texture:t,seconds:An})},Mo=(e=Rs,t=Eh)=>Q({recipe:e,count:t}),ke=(e,t,o=1,n=.4)=>Ie({texture:e,colour:t,size:o,seconds:n,grow:1.6,growFrom:.4,fadeTail:.5}),kt=(e,t=1,o=L(20))=>Ie({texture:w.explosion,colour:e,size:y(256)*t,seconds:o,cells:Is,fadeTail:.25}),Mh=(e,t=1)=>o=>{Da.meltSnow(o.x,o.z,e,t)},Rh=(e,t=1)=>(o,n)=>{Da.burnGrass(n.scene,o.x,o.z,e,t)},_n=Y(kt(b.fire),Mo(Hn,16),Q({recipe:Cs,count:6}),Mh(1.2),Rh(1.2)),Fa=Y(ke(w.thunder,b.arc,1.3,.3),Mo(Fn,20)),Ua=(e,t=L(20),o=2.5)=>De({texture:w.magicGround2,colour:e,seconds:t,scale:o,spin:60,growFrom:.5}),Oh=(e=b.holy)=>Y(Ua(e),Q({recipe:Bn,count:24,height:.2})),Wa=(e=b.gold,t=4)=>De({texture:w.shockwave,colour:e,seconds:.6,scale:t,grow:2,growFrom:.2,fadeTail:.6}),Ro=Y(Mo(Un,14),ke(w.spark2,b.steel,.8,.25)),Oo=Ao(Ie({texture:w.magicCircle,colour:b.energy,size:.5,seconds:.4,spin:6,grow:1.4})),Ch=(e=[.5,.5,.5])=>Y(kt(e),Q({recipe:Ds,count:20})),Ba=1;function Ka(e){return e.enhanced&&Wn()>=Ba?{...e,...e.enhanced}:e}const kh=(e,t,o,n=.6,a=tt(60))=>({speed:a,head:{texture:e,colour:t,size:n},trail:{recipe:o,rate:30}}),$h=(e=C.arrow,t=b.steel)=>({speed:za,model:{model:e,colour:t,scale:1}});function Tn(e,t){Ao(Ua(b.holy,L(20),2.5),0)(e,t),Q({recipe:ks,count:12})(e,t)}const Ih=L(14),Yf=e=>(t,o)=>{const n=G;Ah(Ih,(a,l)=>{G=n,e(a,l)})(t,o)},Et={};function Co(e,t,o,n){const a=n.model?.model,l=a?Kh[a]:void 0;let r=!1;if(l&&n.model){const{scale:c,bodiless:h,lightAtStart:f,...p}=l;n={...n,...p,puffs:[...n.puffs??[],...p.puffs??[]],model:{...n.model,scale:c??n.model.scale}},h&&delete n.model,r=!!f}const i=t.clone(),s=a?q.arrow(e,o,a,c=>{c.x=i.x,c.y=i.y,c.z=i.z}):null;S.spawn("projectile",e,t,{...n,trace:c=>{r||i.copyFrom(c)},onArrive:c=>{s?.stop(),n.onArrive?.(c)},onLost:()=>{s?.stop(),n.onLost?.()}})}function qf(e,t,o,n,a,l=Lh,r=1,i=0){const s=A(t.caster,Xe,new m),c=Math.hypot(e.x-s.x,e.z-s.z)||1,h=Math.atan2(e.x-s.x,e.z-s.z),f=G,p=Et[f],v=(p&&Ka(p).impact)??Ro,d=g=>{const E=g===0||i<=0?s:A(t.caster,Xe,new m),_=h+(typeof l=="number"?(g-(o-1)/2)*l:l[g]??0),T=new m(E.x+Math.sin(_)*c,e.y+B*.5,E.z+Math.cos(_)*c);Co(t.scene,E,ot(f),{to:T,speed:za,model:{model:n,colour:a,scale:r},onArrive:R=>{G=f,v(R,t)}})};for(let g=0;g<o;g++)g===0||i<=0?d(g):z(g*i,()=>{K(t.caster)||d(g)})}let G=0;const Va={},jf={},Dh={cast:Oo,travel:kh(w.thunder,b.arc,Fn),impact:Fa},Nh={cast:Oo,area:Y(De({texture:w.magicGround,colour:b.energy,seconds:1,scale:3,spin:60}),Ot(Fa,4,1.5,.05))},Ph={cast:Oo,area:Y(De({texture:w.magicGround2,colour:b.shade,seconds:1.2,scale:3,spin:-40}),Q({recipe:$o,count:30})),impact:Y(ke(w.flare,b.shade,1.2,.4),Q({recipe:$o,count:16}))},zh={cast:Ga(),impact:Ro},Hh={cast:Ga(),area:Y(Wa(b.gold,3.5),Ot(Ro,4,1.5,.04))},Mn={impact:Y(ke(w.shiny,b.holy,1.3,.6),Q({recipe:Bn,count:16,height:.4})),area:Ao(ke(w.shiny,b.holy,1.3,.6),.8)},Gh={impact:Oh()},Fh={area:Tn,impact:Tn},Uh={area:Y(Wa(b.fire,5),Ot(_n,6,2,.04)),impact:_n},Wt={};function Wh(e){if(!e)return Wt;const t=e.type==="AreaSkillAutomaticHits"||e.type==="AreaSkillExplicitTarget";switch(e.type){case"PassiveBoost":return Wt;case"Buff":return Mn;case"Regeneration":return Gh;case"SummonMonster":return Fh}switch(e.damageType){case"Wizardry":return t?Nh:Dh;case"Curse":return Ph;case"Physical":return t?Hh:zh;case"Fenrir":return Uh;default:return e.type==="DirectHit"?Mn:Wt}}function ot(e){return Et[e]?e:Va[e]??e}function Ya(e){return Ka(Et[e]??Et[Va[e]??-1]??Wh($s(e)))}function ko(e,t,o){return{scene:e,caster:t,target:o,yaw:ge(t)}}function qa(e,t,o){const{release:n,...a}=e.travel;if(!n)return Rn(e,a,t,o);const l=G;_o(t,()=>{K(t.caster)||K(o)||(G=l,Rn(e,a,t,o))},n===!0?{}:n)}function Rn(e,t,o,n){const{fromSky:a,skyOffset:l,bowArrow:r,...i}=t;r&&(i.model={...ja(o.caster),scale:1});const s=a?A(n,B,new m):A(o.caster,Xe,new m);if(a){const[h,f,p]=l??[1.5,8,1];s.x+=h,s.y+=f,s.z-=p}else{const f=A(n,B,new m).subtract(s).normalize();s.addInPlace(f.scaleInPlace(.4))}const c=G;Co(o.scene,s,ot(c),{...i,to:xe(n,B),onArrive:h=>{K(n)||(G=c,e.impact?.(h,o))}})}function Xf(e,t,o,n){if(xo(o,ot(t),performance.now())){if(o.transform){G=t;const a=Ya(t),l=ko(e,o,n);Ha(l);const r=n?.transform?A(n,B,new m):A(o,B,new m);a.cast?.(r,l),a.travel&&n?.transform?qa(a,l,n):a.impact?a.impact(r,l):a.area&&(r.y-=B,a.area(r,l))}q.skillTargeted(e,t,o,n)}}function Zf(e,t,o,n,a,l=null){if(!xo(o,ot(t),performance.now()))return;const r=n?n.x:o.transform.pos.x,i=n?n.y:o.transform.pos.z,s=a(r,i);if(o.transform){G=t;const c=Ya(t),h=l?.transform?l:null,f=ko(e,o,h);Ha(f);const p=new m(r,s,i);c.cast?.(p,f),c.travel&&h?qa(c,f,h):c.area?c.area(p,f):c.impact&&(h?A(h,B,p):p.y+=B,c.impact(p,f))}q.skillArea(e,t,o,{x:r,y:s,z:i})}const Bh={},Kh={},Vh=y(135),Yh=y(60),qh=Ch(b.fire),jh={model:C.arrow,colour:b.steel};function ja(e){const t=co.equippedLauncher(To(e));return t&&Bh[t.num]||jh}function Jf(e,t,o){if(!co.equippedLauncher(To(t))||K(t)||K(o)||!xo(t,0,performance.now()))return;const n=ja(t),a=A(t,Vh,new m),l=A(o,B,new m);a.addInPlace(l.subtract(a).normalize().scaleInPlace(Yh));const r=ko(e,t,o);Co(e,a,0,{...$h(n.model,n.colour),to:xe(o,B),...n.model===C.arrowBomb?{onArrive:i=>qh(i,r)}:{}})}const Xh={count:5,width:.2,colour:[.4,.8,.2],radius:.8,base:1.1,lift:1.2,flare:!0},Xa={},Zh={},On={};function Qf(e,t,o){if(t.buffs)for(const n in On)t.buffs.has(+n)&&On[n](e,t,o)}const Za=[{key:-1,ids:[1,2,3],look:()=>({spearJoints:Xh})}],Ke=new WeakMap;function Lt(e,t,o,n){let a=Ke.get(t);const l=a?.get(o);if(l&&(!n||!l.alive)&&(l.stop(),a.delete(o)),!n){a&&a.size===0&&Ke.delete(t);return}if(l?.alive||!t.transform)return;a||(a=new Map,Ke.set(t,a));const r=S.spawn("aura",e,A(t,0,new m),{...n(t,e),follow:i=>A(t,0,i),bone:(i,s)=>Gn(t,i,s),boneCount:()=>Math.max(0,(t.modelObject?.gltf?.skeleton?.bones.length??0)-1),until:()=>K(t)});a.set(o,r)}function ed(e,t,o,n){if(!Zh[o]?.(e,t,n)){Lt(e,t,o,n?Xa[o]??null:null);for(const a of Za){if(!a.ids.includes(o))continue;const l=n||a.ids.some(r=>t.buffs?.has(r));Lt(e,t,a.key,l?a.look:null)}}}function td(e,t){const o=t.buffs;if(o){for(const n of o)Lt(e,t,n,Xa[n]??null);for(const n of Za)n.ids.some(a=>o.has(a))&&Lt(e,t,n.key,n.look)}}function od(e){const t=Ke.get(e);if(t){for(const o of t.values())o.stop();Ke.delete(e)}}const Jh=Math.PI/180,nd=(e,t)=>{const o=t.caster.transform;o&&gi(G,{x:o.pos.x,z:o.pos.z})},Qh={color:[1,2,1.6],range:3,seconds:.8,release:.8},ad=(e,t=.6)=>Ot((o,n)=>xh({model:Math.random()<.5?C.stone:C.stone2,seconds:1,colour:b.gold,rise:2.5,spin:6,scale:.7})(o,n),e,t),sd=1,Ja={texture:w.spark,colour:b.white,size:.02,sizeJitter:0,stretch:12.5,stretchBySpeed:!0,aimed:!0,life:L(15),lifeJitter:7/15,box:[.1,0,.1],dir1:[0,0,0],dir2:[0,0,0],power:tt(25),powerJitter:19/25,capacity:600},rd=(e,t,o=new m)=>o.set(Math.sin(t)*Math.cos(e),-Math.sin(e),-Math.cos(t)*Math.cos(e)),id=(e,t,o)=>(n,a)=>{const l=ge(a.caster),r=o.pitch??0;for(let i=0;i<e;i++){const s=Ct(l+i*t),c=new m(s.x*Math.cos(r),Math.sin(r),s.z*Math.cos(r));S.spawn("joint",a.scene,n,{...o,heading:c})}},Cn=e=>Math.floor(e/me+1e-6),eu=[[C.multishot3,20,12,.25],[C.multishot3,20,12,.25],[C.multishot,0,16,.2],[C.multishot,0,16,.2],[C.multishot,0,16,.2],[C.multishot2,20,13,.3],[C.multishot2,20,13,.3]],tu=[.8,.9,1.6];function ou(e,t){const o=A(e.caster,0,new m),n=t*Jh;for(const[a,l,r,i]of eu){const s=60-l,c=new m(o.x+y(s*Math.sin(n)-10*Math.cos(n)),o.y+y(135),o.z-y(s*Math.cos(n)+10*Math.sin(n)));S.spawn("model",e.scene,c,{model:a,seconds:L(r),scale:0,scaleAt:h=>i*Cn(h),angle:[0,0,t],colour:tu,keysPerTick:1/6,blendMesh:0,blendLight:h=>(r+1-Cn(h))/18,blendClamp:!0,fadeTail:0})}}const ld=(e,t)=>ou(t,nu(ge(t.caster)));function cd(e,t,o,n,a){return(l,r)=>{for(let i=0;i<e;i++){const s=i*Math.PI*2/e,c=N(),h=f=>{const p=N()-c,v=s+p*4;return f.set(l.x+Math.cos(v)*y(80),l.y+.2+p*1.2,l.z+Math.sin(v)*y(80))};S.spawn("joint",r.scene,l,{head:h,maxTails:n,width:o,colour:t,seconds:a,texture:w.jointEnergy})}}}function hd(e,t){const o=ve.world?.getTerrainLight(e.x,e.z),n=o?.x??1,a=o?.y??1,l=o?.z??1;return[Math.min(1,n+t[0]),Math.min(1,a+t[1]),Math.min(1,l+t[2])]}function ud(e,t){const o=ve.world?.getTerrainLight(e,t);return o?.2126*o.x+.7152*o.y+.0722*o.z:1}const fd=e=>Math.floor(Math.random()*e);function Qa(e,t,o){const n=ve.world?.getTerrainHeight(e,t);return n===void 0||n<-9e3?o:n}const dd=.25,pd={enhanced:{impact:Y(ke(w.shiny,b.steel,.9,.5),Ie({texture:w.flare,colour:[.5,.53,.65],size:2,seconds:.7,growFrom:.5,grow:1.2,fadeTail:.6}),Q({recipe:Un,count:22}),De({texture:w.shockwave,colour:[.8,.84,1],scale:.8,grow:4,seconds:.6,fadeTail:.6}))}},Ee=e=>e*Math.PI/180,nu=e=>e*180/Math.PI;function md(e,t,o){const n=Math.sin(Ee(e[0])),a=Math.cos(Ee(e[0])),l=Math.sin(Ee(e[1])),r=Math.cos(Ee(e[1])),i=Math.sin(Ee(e[2])),s=Math.cos(Ee(e[2]));return o.set(-(n*l*s-a*i)*t,-(n*r)*t,-(n*l*i+a*s)*t)}function gd(e,t,o){const n=((t-e)%360+540)%360-180;return Math.abs(n)<=o?e+n:e+Math.sign(n)*o}const es=e=>{const t=new m;return o=>{e(t),o.x=t.x,o.y=t.y,o.z=t.z}},au=(e,t)=>ve.world?.getTerrainHeight(e,t)??0,vd=()=>ve.world?.playerEntity??void 0,wd=()=>ve.world?.mapIndex,Sd=e=>t=>(e(t),t.y=au(t.x,t.z)+.04,t),yd=e=>t=>t.copyFrom(e),bd=(e,t)=>o=>Math.min(1,e*t(o/me)),Ed=(e,t,o,n,a=!0,l="fire")=>(r,i)=>{const s=r.clone(),c=N();let h=0,f=!1;const p=()=>{if(K(i.caster))return;const v=i.caster.modelObject,d=!!v&&v.CurrentAction===e;if(f||=d,f&&!d){l==="fire"&&n(s,i);return}if(d&&v.actionFrame()>=t){n(s,i);return}if(h>=o){a&&n(s,i);return}h++,z(c+L(h)-N(),p)};p()};function Ld(e,t,o,n,a){const l=N();let r=0,i=!1;const s=()=>{r++;const c=e.caster.modelObject,h=!K(e.caster)&&c?.CurrentAction===t;if(i||=h,K(e.caster)||i&&!h){a?.();return}if(h&&c&&n(c.actionFrame(),r),r>=o){a?.();return}z(l+L(r+1)-N(),s)};z(L(1),s)}const xd=33;function Ad(e,t,o,n){const a=e+Math.floor(o/40),l=(a+55555)*.048*t,r=a*.0613*t,i=(a+11111)*.1113*t,s=Math.sin(l)*Math.cos(r),c=Math.sin(l)*Math.sin(r),h=Math.cos(l);return n.set(Math.cos(i)*c-Math.sin(i)*h,s,Math.sin(i)*c+Math.cos(i)*h)}const su=e=>{const{x:t,y:o,z:n}=e;return a=>{a.x=t,a.y=o,a.z=n}},xt=(e,t)=>{Vn(e,t,{bus:ho})},ts=20*Math.PI/180,ru=[.5,.1,1],iu=y(64),lu=e=>Math.sin((20-20*e)*10*Math.PI/180)*3+2,cu=(e,t)=>{for(let n=0;n<6;n++)S.spawn("debris",t.scene,e,{model:Math.random()<.5?C.stone:C.stone2,colour:b.white});const o=new m(e.x,e.y+y(80),e.z);Ie({texture:w.ring,colour:b.white,size:iu,seconds:L(20),fadeTail:.25,sizeAt:lu})(o,t),kt(b.white)(o,t),xt("Sound/eExplosion",o),q.skillSpot(t.scene,13,"blast",n=>{n.x=e.x,n.y=e.y,n.z=e.z})},hu=e=>(t,o)=>{const n=y(300+Math.floor(Math.random()*500)),a=new m(t.x+y(200+Math.floor(Math.random()*100)),t.y+n,t.z+y(Math.floor(Math.random()*100)-50)),l=new m(a.x-n*Math.tan(ts),0,a.z);l.y=Qa(l.x,l.z,t.y);const r=a.clone(),i=f=>f.copyFrom(r);let s=!1;const c=q.skillSpot(o.scene,13,"comet",es(i));S.spawn("joint",o.scene,a,{head:i,maxTails:10,width:1,colour:ru,texture:w.jointLaser,seconds:L(30),fadeTail:.01,until:()=>s});const h=tt(50+Math.floor(Math.random()*50));e?.flight(i,m.Distance(a,l)/h,o),S.spawn("projectile",o.scene,a,{to:l,speed:h,model:{model:C.blast,colour:b.white,scale:1+Math.floor(Math.random()*8)*.1,blendMesh:0,alongPath:!0},trace:f=>r.copyFrom(f),onArrive:f=>{s=!0,c?.stop(),cu(f,o),e?.land(f,o)},onLost:()=>{s=!0,c?.stop()}})},_d=hu(),uu=()=>Math.random()<.5?C.stone:C.stone2,fu={texture:w.fire,cells:{w:64,h:64,count:4},colour:[.085,.85,0],colourEnd:[0,0,0],size:1.02,sizeJitter:.2,life:L(24),box:[.25,0,0],dir1:[0,0,-1.2],dir2:[0,.1,-.8],power:1,gravity:0,spin:2.2,endScale:.4,blend:"add",capacity:256},du=e=>({texture:w.smoke,colour:e,colourEnd:[0,0,0],size:1.53,sizeJitter:.16,life:L(50),box:[.32,.315,.32],dir1:[-1,-1.4,-1],dir2:[1,0,1],power:.35,gravity:0,endScale:2.05,blend:"add",capacity:128}),pu=y(63.5),no=[.1,.5,.1],mu=du(no),gu=15,Bt=12,Kt=.3,vu=(e,t,o,n)=>{S.spawn("model",t.scene,e,{model:C.inferno,seconds:L(Bt),scale:Kt,grow:(Kt+.04*Bt)/Kt,colour:[0,.5,0],hideMesh:0,keysPerTick:.5,life:l=>Bt*(1-l)/20});const a=new m;for(let l=0;l<gu;l++)a.set(e.x+y(Math.floor(Math.random()*160)-80),e.y+y(50),e.z+y(Math.floor(Math.random()*160)-100)),Q({recipe:o,count:1,height:n})(a,t);for(let l=0;l<6;l++)S.spawn("debris",t.scene,e,{model:uu(),colour:no});kt(no)(a,t),q.skillSpot(t.scene,38,"blast",su(a)),xt("Sound/eBlastPoison_2",e),xt("Sound/eExplosion",a)},wu=(e,t=mu,o=pu)=>(n,a)=>{const l=y(500+Math.floor(Math.random()*300)),r=new m(n.x+y(200+Math.floor(Math.random()*100)),n.y+l,n.z+y(Math.floor(Math.random()*100)-50)),i=new m(r.x-l*Math.tan(ts),0,r.z);i.y=Qa(i.x,i.z,n.y);const s=tt(50+Math.floor(Math.random()*50)),c=m.Distance(r,i)/s,h=r.clone(),f=d=>d.copyFrom(h),p=q.skillSpot(a.scene,38,"comet",es(f)),v={seconds:c,follow:f,fadeTail:.01};S.spawn("sprite",a.scene,r,{...v,texture:w.flare,colour:[.5,.5,1],size:y(64*3)}),S.spawn("sprite",a.scene,r,{...v,texture:w.shiny2,colour:b.white,size:y(32*3),aspect:2,blend:"subtract",reroll:{every:me}}),S.spawn("sprite",a.scene,r,{...v,texture:w.shiny2,colour:[.8,.5,.1],size:y(32*4),aspect:2,reroll:{every:me}}),S.spawn("joint",a.scene,r,{head:f,maxTails:20,width:1,colour:b.white,texture:w.flareBig,seconds:L(20),fadeTail:.05}),e?.flight(f,c,a),S.spawn("projectile",a.scene,r,{to:i,speed:s,trail:{recipe:fu,rate:50},trace:d=>h.copyFrom(d),onArrive:d=>{h.copyFrom(d),p?.stop(),vu(d,a,t,o),e?.land(d,a)},onLost:()=>p?.stop()})},Su=e=>(t,o)=>{e(t,o),e(t,o),xt("Sound/eBlastPoison_1",t)},Td=Su(wu()),yu=21,ao=[.5,1,.8],bu={texture:w.flare,colour:[.6,1,.85],colourEnd:[.1,.35,.3],size:.14,sizeJitter:.4,life:.6,lifeJitter:.3,box:[.35,.5,.35],dir1:[-1,.6,-1],dir2:[1,1.6,1],power:2.4,powerJitter:.5,gravity:-3,endScale:.4,capacity:64};function Eu(e,t,o,n,a,l,r){const i=a.clone(),s=l?c=>{l(i),c.x=i.x,c.y=i.y,c.z=i.z}:void 0;q.flash(e,jn(t,o,n,r),{position:{x:a.x,y:a.y,z:a.z},follow:s})}function Lu(e,t,o){const n=xe(t,.04);S.spawn("sprite",e,o,{texture:w.flare,colour:Io(ao,.35),size:3.2,growFrom:.4,seconds:L(24),fadeTail:.5,flat:!0,follow:n}),S.spawn("sprite",e,o,{texture:w.ring,colour:Io(ao,.9),size:1,grow:3.6,growFrom:1,seconds:L(14),fadeTail:.7,flat:!0,follow:n}),S.spawn("particles",e,o,{recipe:bu,count:22,height:.8}),S.spawn("particles",e,o,{recipe:Ns,count:5,height:.1})}function Md(e,t){if(!t.transform)return;const o=A(t,0,new m);if(S.spawn("model",e,o,{model:C.magicCircle,seconds:L(30),scale:.7,grow:1/.7,colour:b.white,yaw:-ge(t),follow:xe(t,0),fadeTail:0,keysPerTick:.1}),S.spawn("sprite",e,o,{texture:w.lightning2,colour:[1,2,1.6],size:y(128)*1.6,growFrom:1/1.6,grow:3/1.6,seconds:L(20),fadeTail:1,follow:xe(t,y(80))}),Wn()>=Ba){Lu(e,t,o);const n=xe(t,y(80));Eu(e,ao,1.9,L(20),n(new m),n,{release:L(18)})}else{const n=new m;q.flash(e,Qh,{position:A(t,y(80),new m),follow:a=>{A(t,y(80),n),a.x=n.x,a.y=n.y,a.z=n.z}})}if(t.npcType===yu){t.monsterAnimation&&(t.monsterAnimation.action=xr.Stop2),Me("Sound/mAssassin1",t.transform.pos);return}t.modelObject?.setAlpha(0);for(let n=1;n<=20;n++)z(L(n),()=>t.modelObject?.setAlpha(n*.05))}const Rd={min:.75,max:1,steps:4},Od=e=>(t,o)=>{q.flash(o.scene,e,{position:{x:t.x,y:t.y,z:t.z}})};function Cd(e,t,o){const n=new m;o(n),q.flash(e.scene,t,{position:{x:n.x,y:n.y,z:n.z},follow:a=>{o(n),a.x=n.x,a.y=n.y,a.z=n.z}})}function kd(e){e.copyWithin(0,3),e.length-=3}function $d(e,t){const o=Math.min(e.length,t.length);for(let n=0;n<o;n++)t[n]=e[n];return o/3}const Id={horse:ue.PLAYER_ATTACK_RIDE_ATTACK_MAGIC,uniria:ue.PLAYER_SKILL_RIDER,dinorant:ue.PLAYER_SKILL_RIDER_FLY,fenrir:ue.PLAYER_FENRIR_ATTACK_MAGIC},Dd={horse:ue.PLAYER_ATTACK_RIDE_ATTACK_MAGIC,fenrir:ue.PLAYER_FENRIR_ATTACK_MAGIC},Nd={fenrir:ue.PLAYER_FENRIR_ATTACK_MAGIC},Pd=.04,zd={enhanced:{cast:jn([.85,.85,.95],1.2,.6,{attack:.05,release:.4})}},Hd=e=>(t,o)=>{const n=e.tiles??1,a={texture:e.texture??w.flare,colour:e.colour,colourEnd:e.end,size:.35,sizeJitter:.4,life:.6,box:[.25,.1,.25],dir1:[-1.2,.6,-1.2],dir2:[1.2,1.8,1.2],power:2.4,gravity:-3,capacity:256},l=(i,s)=>{Ie({texture:w.flare,colour:e.colour,size:1.6*s,seconds:.3,growFrom:.5,grow:1.4,fadeTail:.6})(new m(i.x,i.y+y(80),i.z),o),De({texture:w.shockwave,colour:e.colour,scale:.8*s,grow:2.2,growFrom:.4,seconds:.4,fadeTail:.6})(i,o),Q({recipe:a,count:Math.round(14*s),height:.3})(i,o)},r=e.bursts??1;if(r<=1){l(t,Math.max(1,n/2)),e.sound&&Me(e.sound,t);return}for(let i=0;i<r;i++){const s=Math.random()*Math.PI*2,c=Math.sqrt(Math.random())*n;z(i*.08,()=>{const h=new m(t.x+Math.cos(s)*c,t.y,t.z+Math.sin(s)*c);l(h,1),e.sound&&i%3===0&&Me(e.sound,h)})}},Gd=(e,t)=>e+Math.random()*(t-e),Fd=(e,t,o,n)=>e.set(-t,-n,-o),Ud=(e,t)=>{const o=e.caster.transform;o&&Me(t,{x:o.pos.x,z:o.pos.z})};function Wd(e){const t=To(e)?.leftHand;if(!t)return null;const o=Ps.getItem(t.group,t.num);if(!o)return null;const n=e.modelObject?.Weapon1?.getMeshes(!0)[0]?.metadata;return{file:o.szModelFolder+o.szModelName,group:t.group,num:t.num,stamp:{itemTier:n?.itemTier??null,itemLvl:n?.itemLvl??0,isExcellent:n?.isExcellent??!1}}}const Bd=e=>e.group===3||e.group===4||e.group===5&&e.num<=13?.7:.8,Kd=[.3,.3,.3],os={texture:w.spark2,colour:b.white,size:.03,life:1.2,power:1.5,gravity:-4,dir1:[-.6,.4,-.6],dir2:[.6,1,.6]};function Vd(e,t,o,n){S.spawn("particles",e,t,{recipe:Ja,count:1,heading:o}),Math.random()<n&&S.spawn("particles",e,t,{recipe:os,count:1})}const Yd={...Ja,colour:[1,.92,.75],colourEnd:[1,.45,.12],size:.024},qd={...os,colour:[1,.85,.55],colourEnd:[1,.35,.08],size:.04,life:.7,power:2.2,gravity:-7,capacity:256},jd=10,Xd=new m,xu=14,Au=5,_u=e=>(t,o)=>{const n=N(),a=()=>{if(K(o.caster))return;const l=o.caster.modelObject,r=l?.CurrentAction??-1,i=r>=zo.PLAYER_ATTACK_SKILL_SWORD1&&r<=zo.PLAYER_ATTACK_SKILL_SWORD5;if(i&&r===o.caster.playerAnimation?.action&&l.actionFrame()>=Au||N()-n>=L(xu)-1e-6){i&&e(t,o);return}z(me/2,a)};a()},Tu=(e,t,o)=>{if(!o.transform)return;const n=A(o,B,new m);q.skillStrike(e,t,{position:{x:n.x,y:n.y,z:n.z},follow:a=>{A(o,B,n),a.x=n.x,a.y=n.y,a.z=n.z}})},Mu=.3,Zd=(e,t)=>{!t.target||K(t.target)||S.spawn("sprite",t.scene,A(t.target,Mu,new m),{texture:w.spark3,size:y(64),seconds:L(3),grow:.5,fadeTail:0})},Ru=.6,kn=.4,Ou=[.8,.85,1],Cu=(e,t)=>(o,n)=>{const a=n.target;if(!a||K(a))return;const l=A(a,Ru,new m),r=Th(l,A(n.caster,0,new m));l.x+=r.x*kn,l.z+=r.z*kn,S.spawn("sprite",n.scene,l,{texture:w.flare,colour:Ou,size:.7,seconds:.2,growFrom:.6,grow:1.1,fadeTail:.7}),S.spawn("sprite",n.scene,l,{texture:w.spark3,size:.75,seconds:L(4),growFrom:1.2,grow:.45,fadeTail:.3}),S.spawn("sprite",n.scene,l,{texture:w.shiny,size:.8,seconds:L(4),growFrom:1.3,grow:.3,spin:4,fadeTail:.4}),S.spawn("particles",n.scene,l,{recipe:t,count:14}),Tu(n.scene,e,a)},Jd=e=>(t,o)=>_u(Cu(ot(G),e))(t,o),ku=(e,t,o)=>Math.max(0,e-(o-1-t)),Qd=(e,t)=>({x:e,z:t,life:25+Math.floor(Math.random()*50),rise:35+Math.floor(Math.random()*20)});function e0(e,t,o,n,a){S.spawn("joint",e,m.Zero(),{paths:{count:t.length,fill:(l,r,i)=>{const s=t[l],c=n();if(c<0||c>s.life)return 0;const h=Math.min(26,Math.max(0,c-ku(r,Math.min(20,c+1),20)-(s.life-25)));return i.set(s.x,o+y(h*s.rise+2.5*h*(h+1)),s.z),1}},maxTails:19,seconds:a,width:y(40),fadeTail:0,colour:b.white,texture:w.flareBig})}export{Ie as $,su as A,Xd as B,ot as C,Jh as D,Gd as E,Rd as F,rd as G,ud as H,zd as I,Ja as J,Ud as K,Fd as L,Id as M,Hf as N,Yd as O,G as P,Jd as Q,_u as R,qd as S,me as T,Zd as U,Nd as V,xd as W,jd as X,Xe as Y,Ad as Z,B as _,Qu as a,Vf as a$,Tu as a0,De as a1,Mh as a2,Rh as a3,ku as a4,Ed as a5,Wd as a6,Kd as a7,Bd as a8,bd as a9,wu as aA,Td as aB,Uf as aC,ad as aD,Pf as aE,Ee as aF,Mo as aG,Nf as aH,Et as aI,Va as aJ,Vt as aK,aa as aL,sa as aM,pi as aN,mi as aO,jf as aP,vh as aQ,Xa as aR,Zh as aS,On as aT,co as aU,Bh as aV,Kh as aW,du as aX,uu as aY,nu as aZ,gd as a_,Qa as aa,kt as ab,zf as ac,Vd as ad,dd as ae,Th as af,Qd as ag,e0 as ah,yi as ai,ho as aj,_o as ak,Bf as al,To as am,Pd as an,wd as ao,hd as ap,xh as aq,Ba as ar,Hd as as,sd as at,pu as au,xt as av,_d as aw,hu as ax,mu as ay,Su as az,Me as b,fc as b$,Fa as b0,Ju as b1,Lt as b2,Ya as b3,ko as b4,es as b5,Oh as b6,$h as b7,Eu as b8,Kf as b9,uh as bA,ed as bB,td as bC,od as bD,Md as bE,nn as bF,Cf as bG,kf as bH,wf as bI,Sf as bJ,yf as bK,bf as bL,vf as bM,mf as bN,gf as bO,pf as bP,Lf as bQ,$f as bR,If as bS,Mf as bT,_f as bU,Tf as bV,Of as bW,Af as bX,Rf as bY,Ef as bZ,Wl as b_,Ro as ba,ja as bb,qf as bc,ld as bd,Wf as be,Tn as bf,Lh as bg,of as bh,Wa as bi,_n as bj,md as bk,Cn as bl,au as bm,vd as bn,ou as bo,Ld as bp,gi as bq,Yf as br,Sd as bs,yd as bt,Hu as bu,Mi as bv,Jf as bw,Qe as bx,Uu as by,Gu as bz,ef as c,xf as c0,lh as c1,ih as c2,Bu as c3,Wu as c4,Zf as c5,Xf as c6,Gf as c7,Qf as c8,Yu as c9,ia as cA,lf as cB,Ku as cC,Fu as cD,Df as cE,qu as ca,Ri as cb,os as cc,Da as cd,bi as ce,nf as cf,sf as cg,Si as ch,af as ci,tf as cj,rf as ck,Ko as cl,Vu as cm,ju as cn,Xu as co,uo as cp,ca as cq,Sl as cr,df as cs,cf as ct,Mc as cu,uf as cv,Xo as cw,Ji as cx,hf as cy,ff as cz,tt as d,Ah as e,Q as f,ke as g,Ff as h,gt as i,Ao as j,cd as k,nd as l,y as m,Ua as n,Dd as o,Zu as p,pd as q,Ct as r,Y as s,L as t,Od as u,Cd as v,kd as w,$d as x,fd as y,id as z};
