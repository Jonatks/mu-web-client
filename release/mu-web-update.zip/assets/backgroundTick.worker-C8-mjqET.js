(function(){"use strict";setInterval(()=>postMessage(0),40)})();
